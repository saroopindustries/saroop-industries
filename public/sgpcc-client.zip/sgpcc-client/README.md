# SGPCC — Shree Ganesh Plywood & Construction Chemicals

Marketing website for SGPCC: building materials, construction chemicals, and authorised UltraTech dealer.

## Tech stack

- **Next.js 15+** (App Router)
- **TypeScript**
- **Tailwind CSS v4**
- **shadcn/ui** (Button, Card, Input, Sheet, Accordion, Badge, Separator)
- **SASS** (optional modules in `src/styles/`)
- **Framer Motion** (animations)
- **Swiper** (partner marquee)

## Requirements

- **Node.js >= 20.9.0** (required by Next.js 16)

## Getting started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Build

```bash
npm run build
npm start
```

## Project structure

- `src/app/` — Routes and pages
- `src/components/` — Layout, home, products, partners, shared, ui
- `src/data/` — Config and content (site, products, faq, applications, partners)
- `src/lib/` — utils (e.g. `cn`)
- `src/styles/` — Global CSS and SASS variables

## Config

Edit `src/data/site.ts` for company info, contacts, partners, nav and SEO.  
Edit `src/data/products.ts` for categories and products (IndiaMART-sourced list included).

## Assets

Place logo at `public/logo.png`, hero at `public/hero.jpg`, and partner logos under `public/partners/` (e.g. `ultratech.png`). If images are missing, partner names are shown as fallback.



SGPCC Website Redesign Plan

Scope and constraints





Workspace: sgpcc-client is empty; build from scratch (no migration from reference repo).



Reference repo (spfcc-workspace): Use only as a structural cue (Next.js 15, src/app, src/components). Your stack differs (TypeScript, SASS, shadcn, Framer Motion).



Styling: shadcn/ui is Tailwind-based. Use Tailwind + shadcn for UI and layout; use SASS modules for custom section styles (hero, trust strip, industrial patterns, blueprint motifs) so the blueprint’s visual language is achievable without fighting shadcn.



1. Project bootstrap and dependencies





Scaffold: create-next-app@latest with TypeScript, App Router, Tailwind, ESLint. Use src/ directory.



Add:





shadcn/ui – npx shadcn@latest init (Tailwind v4–compatible), then add Button, Card, Input, Sheet (mobile nav), Accordion (FAQ), Badge, Separator, etc. as needed.



SASS – sass for .module.scss files in src/app and src/components.



Framer Motion – framer-motion for section reveals, hero, trust strip, CTA banners.



Swiper – swiper (and swiper/react) for partner logo marquee and any product/category carousels on mobile.



Config: Extend next.config for images (e.g. remotePatterns if using external images) and ensure config.partners[].logo paths under public/ work.



Design tokens: Implement blueprint palette and spacing in one place:





Colors: Primary #0F3D5E, Secondary #6B7280, Accent #F97316, Background #F8FAFC, Dark #111827, Success #16A34A. Expose via Tailwind theme (e.g. globals.css with @theme or tailwind.config) and optionally SASS variables for module-only sections.



Typography: Manrope or Sora for headings, Inter or Plus Jakarta Sans for body (via next/font).



Spacing: 4/8/12/16/24/32/48/64/96; radius md/xl/2xl; container max 1280px; section padding py-16 (mobile) / py-24 (desktop).



2. Config and data layer





Site config: Single source of truth in src/data/site.ts (or config.ts) exporting the provided config object. Type it with a TypeScript interface (e.g. SiteConfig, Partner, Service, Contact, NavItem, SEO).



Products data: src/data/products.ts – build from IndiaMART Our Products page and blueprint categories.

Category → products mapping (IndiaMART as source):







Blueprint / IndiaMART category



Products to list





Cement (Grey & RMC)



Ultratech OPC 43 Grade Cement, Opc Cement (from IndiaMART); keep “RMC” in category copy





Steel & Steel Fibers



Bekaert 3D Dramix Steel Fiber





Construction Chemicals (sub-categories as filters)



Sika (Sikabond SBR Plus, Sika Plastiment 2001 NS, Sika 214 KH Cement Grout, SikaLatex SBR, Sika Chapdur IN Floor Hardener), Fosroc (Fosguard Nitoflor Hardtop, Conplast WL, Nitobond EP, Nitobond SBR, Conbextra GP2), Dr Fixit Pidicrete URP, Kryton Krystol Waterstop Grout variants, Ultratech Weather Pro WP+200, Basf MasterPel 777, Integral Waterproofing Compound





Tile adhesives (under Construction Chemicals or separate)



MYK Laticrete 305 Tile Adhesive, MYK Laticrete SP-100 Tile Joint Adhesive





AAC Blocks, Shuttering Plywood & Pinewood, Epoxy/PU/Industrial Flooring, Insulation



No IndiaMART products; keep as categories with short description and “Explore / Enquire” CTA; optional placeholder “Coming soon” or generic product entries





Data shape: Each product: id, slug, name, category (map to blueprint category slug), brand (e.g. Sika, Fosroc), shortDescription?, applications?, specs?, image?. Categories: id, slug, name, description, productIds or derive from products. Add a brands array per category or from config.partners for filters.



Partners: Use config.partners from site config; no separate partners.ts unless we need extended fields (e.g. category served, spotlight copy) for the Partners page.



FAQ: src/data/faq.ts – array of { question, answer } for the blueprint’s FAQ list (pan-India, bulk orders, brands, quote speed, recommendations, technical guidance, pricing details).



Applications/Industries: src/data/applications.ts – list of use-cases (Residential, Commercial, Industrial, Warehouse & logistics, Repair & waterproofing, Flooring systems) with short copy and optional “recommended products” category slugs.

All content above should be config-based (no CMS); easy to add more products or categories later by editing these files.



3. App structure and routing

src/
  app/
    layout.tsx              # Root layout: fonts, Header, Footer, StickyMobileCTA
    page.tsx                # Home
    products/
      page.tsx              # Products listing (filters, category sections)
      [slug]/page.tsx       # Product detail (dynamic)
    partners/page.tsx
    applications/page.tsx
    about/page.tsx
    delivery/page.tsx
    contact/page.tsx
    faq/page.tsx
    thank-you/page.tsx      # Post quote submit
    privacy/page.tsx
    terms/page.tsx
    not-found.tsx           # 404
  components/
    layout/                 # Header, Footer, MobileNavDrawer, StickyMobileCTA
    home/                   # Hero, TrustStrip, ProductCategories, WhyChoose, etc.
    products/               # ProductFilters, ProductCategoryCard, ProductDetail*
    partners/               # PartnerCard, PartnerLogoGrid
    shared/                 # SectionHeading, CTAButtons, TrustBadge, QuoteForm, FAQAccordion, etc.
    ui/                     # shadcn components
  data/
    site.ts                 # Full config (exported)
    products.ts             # Categories + products (IndiaMART + blueprint)
    faq.ts
    applications.ts
  styles/
    globals.css             # Tailwind + theme
    _variables.scss         # SASS tokens for modules (optional)
  lib/
    utils.ts                # cn(), etc.





Metadata/SEO: Per-route metadata and generateMetadata where needed (e.g. products/[slug]). Use config.seo for default title/description; sitemap via app/sitemap.ts using config.siteUrl and all routes.



4. Layout and global components





Header (desktop): Logo, nav links (Home, Products, Partners, Applications, About, Contact), sticky “Get Quote” + “Call Now” CTAs. Use shadcn Button and nav pattern; optional small trust badge (e.g. “Authorized UltraTech Dealer”).



Mobile: Compact header + hamburger; Sheet/drawer for nav; prominent Call / WhatsApp in drawer and in StickyMobileCTA.



StickyMobileCTA: Fixed bottom bar (mobile only): Call, WhatsApp, Get Quote. Use config contacts.



Footer: Quick links, contact info, address, email, map link, WhatsApp; optional small partner strip. Use config.

Nav and footer links must match blueprint: /, /products, /partners, /applications, /about, /delivery, /contact, /faq.



5. Home page (sections in order)





Hero – Eyebrow, H1 (“Building Materials for Projects, Dealers & Contractors”), supporting copy, “Get Bulk Quote” / “View Products”, quick chips (same day response, bulk pricing, pan-India, authentic brands). Right: image collage or placeholder + optional floating stat cards. Use Framer Motion for entrance; SASS module for custom background/overlay if needed.



Trust strip – UltraTech badge, partner logo marquee (Swiper), optional counters (categories, partners, pan-India, response). Framer Motion for reveal.



Product categories – Grid of category cards (Cement & RMC, Steel & Steel Fibers, Construction Chemicals, AAC Blocks, Plywood, Epoxy/PU/Industrial Flooring, Insulation); each: icon/image, short description, “Explore category” linking to /products#category-slug or filtered view.



Why choose SGPCC – 4-column value props (Authentic products, Reliable sourcing, Bulk order support, Fast quote turnaround).



Featured partners – Brand logo grid (from config), hover effect; CTA to /partners.



Applications – Use-case grid (Residential, Commercial, Warehouses, Factories, Infrastructure, Waterproofing & repair); link to /applications.



How it works – 3 steps: Share requirement → Get quote → Receive supply/dispatch.



Testimonial / trust – Short “Preferred by contractors and distributors” / dealer trust copy (no fake quotes).



CTA banner – Dark section: “Need urgent supply or bulk pricing?” + Call / WhatsApp / Quote CTA.



Footer – As in layout.

Use SectionHeading and shared CTAButtons/TrustBadge for consistency.



6. Products page





Intro hero – H1 “Building Products & Construction Materials”, short B2B copy, search (client-side filter by name/description), filter chips (Category, Brand).



Filter/sort – Category dropdown or chips, Brand dropdown (from product brands + config.partners). On mobile: bottom sheet or collapsible panel for filters (shadcn Sheet or Accordion).



Category sections – For each category, a ProductCategoryCard: cover image, title, description, list of sub-items (product names or first N products), “Quick inquiry” CTA. Products with no IndiaMART items (AAC, Plywood, Flooring, Insulation) still get a card with “Enquire” CTA.



SEO: title/description focused on building products, construction materials, Bhiwadi/India.

Product detail page (products/[slug]):





Content: Breadcrumb, product name, gallery (placeholder if no image), key highlights, specs table (if in data), available brands, applications, packaging/supply notes, FAQ snippet, related products (same category).



Sidebar (or below on mobile): CTA card – Phone, WhatsApp, short quote form or link to /contact.



generateStaticParams from data/products.ts for all product slugs.



7. Partners page





Hero + trust copy; optional stats row.



Featured partner logos grid (from config).



Partner spotlight cards – For key partners (UltraTech, Pidilite, MYK Laticrete, Sika, Birla White, Fosroc, Mapei, Kryton, Supreme, STP, MC-Bauchemie, BASF): logo, category served, short “what it’s used for”, trusted supply note. Extend config or a small partners.ts with this copy.



“Why our partnerships matter” section.



CTA banner for bulk enquiries.



8. Applications, About, Delivery, Contact, FAQ





Applications – Hero + industry grid (Residential, Commercial, Industrial, Warehouse, Repair & waterproofing, Flooring); optional “recommended materials” by use-case from applications.ts; consultation CTA.



About – Company intro, mission, why customers trust us, authorised dealer positioning, operational strength, team/contact persons (use config names/numbers), office/warehouse, CTA.



Delivery – Pan-India promise, regions/states, supply model, bulk process, dispatch/logistics, quote CTA.



Contact – Hero; quick actions (Call Kamal, Call Rinku, Office, WhatsApp, Email); quote form (Name, Company, Phone, Email, Product category, Quantity/requirement, Delivery location, Message); office card + map embed (Google Maps iframe or link); FAQ snippet. Form can be client-side only (mailto or link to WhatsApp) or integrate a simple API/Formspree later.



FAQ – Accordion (shadcn) from faq.ts; questions as in blueprint.



Thank-you – Simple confirmation after quote submit (and redirect from Contact form).



Privacy / Terms – Static pages; placeholder content or links to external docs.



404 – Branded not-found page with links home/products/contact.



9. SEO and performance





Metadata: Default in layout.tsx from config.seo; override in each page; product pages via generateMetadata with product name and description.



Sitemap: app/sitemap.ts – base URL from config, list all static routes + product slugs.



Semantic HTML: Correct heading hierarchy (single H1 per page), sections, nav, footer.



Images: Next.js Image; optimize logo/hero/partners; use sizes and lazy loading.



Mobile-first: Breakpoints for sticky CTA, filter drawer, 1-column cards, large tap targets; test partner marquee on small screens.



10. Design and UX details





Industrial but modern: Clean cards, rounded-xl/2xl, soft shadows, bordered sections; trust logos monochrome by default, color on hover.



Optional motifs: Subtle grid/blueprint patterns or textures in SASS modules (e.g. hero, CTA banner) to match “UltraTech-authorized industrial supplier meets premium B2B catalog.”



Accessibility: Focus states, aria-labels on icon buttons (Call, WhatsApp), form labels.



No horizontal scroll for main content; horizontal scroll only for logo marquee or chips.



11. Implementation order (suggested)





Next.js + TypeScript + Tailwind + shadcn init; SASS + Framer Motion + Swiper; design tokens and fonts.



Config and data: site.ts, products.ts (IndiaMART + blueprint categories), faq.ts, applications.ts.



Layout: Header, Footer, MobileNavDrawer, StickyMobileCTA.



Home: all sections in order (reusable SectionHeading, CTAButtons, TrustBadge, StatsStrip, ProductCategoryCard, BrandLogoGrid).



Products listing + filters + Product detail page with static params.



Partners, Applications, About, Delivery, Contact (with form), FAQ, Thank-you, Privacy, Terms, 404.



Sitemap, metadata, final responsive and SEO pass.



12. Product data summary (IndiaMART → data/products.ts)





Sika Waterproofing: Sikabond SBR Plus, Sika Plastiment 2001 NS, Sika 214 KH Cement Grout, SikaLatex SBR, Sika Chapdur IN Floor Hardener.



Fosroc: Fosguard Nitoflor Hardtop, Conplast WL, Nitobond EP, Nitobond SBR, Conbextra GP2.



Myk Tile Adhesives: MYK Laticrete 305 Tile Adhesive, MYK Laticrete SP-100 Tile Joint Adhesive.



Steel Fiber: Bekaert 3D Dramix Steel Fiber.



Dr Fixit: Dr Fixit Pidicrete URP Waterproofing Chemicals.



Concrete Grouting: 25kg Kryton Krystol Waterstop Grout, Kryton Krystol Waterstop Grout Smart Concrete.



Integral Waterproofing: Ultratech Weather Pro WP+200; generic Integral Waterproofing Compound.



Basf: Basf MasterPel 777 Concrete Admixture.



Cement: Ultratech OPC 43 Grade Cement, Opc Cement.

Map these into blueprint categories (Cement, Steel & Steel Fibers, Construction Chemicals with sub-types) and add Cement & RMC, AAC Blocks, Plywood, Flooring, Insulation as categories with description + enquiry CTA only where no IndiaMART products exist.

















### CONTEXT


Tech Stack and packages:

Next, typescript, sass, modules, shadcn/ui, Swiper for carousel if needed, use framer motion for animation if needed

Modern design, mobile and desktop responsive, config based data, SEO optimised, 

https://www.indiamart.com/shreeganeshplywoodconstructionchemicals/our-products.html  this is products page from india mart please pick from. there


https://www.sgpcc.in/ this is current hosted website for same,

const config = {
  siteUrl: 'https://sgpcc.in',
  company: {
    name: 'Shree Ganesh Plywood & Construction Chemicals',
    shortName: 'SGPCC',
    tagline: 'One stop solution for cement, steel, chemicals, AAC blocks, shuttering plywood, pinewood, epoxy & industrial flooring.',
    about:
      'We maintain a network of distributors and partners across India to deliver premium building materials at wholesale rates with reliable service.',
    logo: '/logo.png',
    heroImage: '/hero.jpg',
  },
  contacts: {
    address: 'GROUND FLOOR, KHASRA NO. 403 TO 406, Alwar Bhiwadi Bypass Road, BEHIND SAMRIDDHI RAYMOND SHOWROOM, BHIWADI, Alwar, Rajasthan, 301019',
    phones: [
      { label: 'Kamal Goyal', number: '+91 9610961111' },
      { label: 'Rinku Goyal', number: '+91 9610962222' },
      { label: 'Office', number: '+91 9610967777' },
    ],
    email: 'sgpcc123@gmail.com',
    whatsapp: '+919610961111'
  },
  partners: [
    { name: 'UltraTech Cement', logo: '/partners/ultratech.png', url: 'https://www.ultratechcement.com/' },
    { name: 'Pidilite', logo: '/partners/pidilite.png', url: 'https://www.pidilite.com/' },
    { name: 'MYK Laticrete', logo: '/partners/myk-laticrete.png', url: 'https://myklaticrete.com/' },
    { name: 'Supreme', logo: '/partners/supreme.png', url: "https://www.supreme.co.in/" },
    { name: 'Sika', logo: '/partners/sika.png', url: "https://www.sika.com/" },
    { name: 'Birla White', logo: '/partners/birla-white.png', url: "https://www.birlawhite.com/en" },
    { name: 'STP Limited', logo: '/partners/stp.png', url: "https://stpltd.com/" },
    { name: 'Kryton', logo: '/partners/kryton.png', url: "https://www.kryton.in/" },
    { name: 'Mapei', logo: '/partners/mapei.png', url: "https://www.mapei.com/" },
    { name: 'Fosroc', logo: '/partners/fosroc.png', url: "https://www.fosroc.com/" },
    { name: 'Cipy', logo: '/partners/cipy.png', url: "https://www.drcipy.com/" },
    { name: 'Master Builders', logo: '/partners/mbs.png', url: "https://master-builders-solutions.com/en-in/" },
    { name: 'MC-Bauchemie', logo: '/partners/mc.png', url: "https://www.mc-bauchemie.in/" },
    { name: 'Bekaert', logo: '/partners/bekaert.png', url: "https://www.bekaert.com/en/" },
  ],
  services: [
    { title: 'Cement (Grey & RMC)', description: 'Authorised dealer of non‑trade UltraTech grey cement & RMC across India.' },
    { title: 'Steel & Steel Fibers' },
    { title: 'Construction Chemicals', description: 'Admixtures, waterproofing, repair mortars, grouts & sealants.' },
    { title: 'AAC Blocks' },
    { title: 'Shuttering Plywood & Pinewood' },
    { title: 'Epoxy, PU & Industrial Flooring' },
    { title: 'Insulation' , description: 'Insulation materials for thermal and acoustic protection.' }
  ],
  cta: {
    heading: 'Looking for bulk pricing or urgent delivery?',
    sub: 'Call us now or drop a message on WhatsApp. We will get back within the hour.',
  },
  nav: [
    { label: 'Home', href: '/' },
    { label: 'Services', href: '#services' },
    { label: 'Partners', href: '#partners' },
    { label: 'Contact', href: '#contact' },
  ],
  seo: {
    title: 'SGPCC — Shree Ganesh Plywood & Construction Chemicals',
    description: 'Authorised UltraTech dealer. Supplier of cement, steel, AAC blocks, shuttering plywood, pinewood, epoxy & industrial flooring in Bhiwadi/Alwar, Rajasthan.'
  }
}



# SGPCC Website Redesign Blueprint

## Brand direction

*Positioning:* Premium yet practical B2B building materials supplier for contractors, project owners, dealers, and procurement teams.

*Core message:* One trusted source for cement, steel, chemicals, AAC blocks, plywood, pinewood, flooring, and industrial project materials.

*Tone:* Reliable, industrial, fast-response, authentic, pan-India supply focused.

---

## Proposed visual theme

### 1) Color palette

* *Primary:* Deep Construction Blue #0F3D5E
* *Secondary:* Cement Gray #6B7280
* *Accent:* Safety Orange #F97316
* *Background:* Warm White #F8FAFC
* *Dark Surface:* Charcoal #111827
* *Success / trust:* #16A34A

### 2) Typography

* *Headings:* Manrope / Sora / Inter Tight
* *Body:* Inter / Plus Jakarta Sans
* *Style:* Strong bold headings, generous spacing, readable body copy, clear B2B hierarchy

### 3) Visual language

* Industrial but modern
* Clean cards, rounded-xl to 2xl corners
* Soft shadows, bordered sections
* Product imagery with strong overlays
* Trust logos in monochrome by default, full color on hover
* Repeating visual motifs: grid lines, subtle blueprint patterns, delivery-route dots, warehouse textures

---

## Site architecture

### Main pages

1. *Home*
2. *Products*
3. *Product Details* (dynamic slug pages)
4. *Trusted Partners*
5. *Industries / Applications*
6. *About Us*
7. *Delivery & Service Areas*
8. *Contact / Get Quote*
9. *FAQ*

### Utility pages

* 404 page
* Thank you page after quote submission
* Privacy policy
* Terms & conditions
* Sitemap

---

## Header / Navigation

### Desktop nav

* Logo
* Home
* Products
* Partners
* Applications
* About
* Contact
* Sticky CTA: *Get Quote*
* Secondary CTA: *Call Now*

### Mobile nav

* Compact header
* Hamburger drawer
* Prominent call and WhatsApp actions fixed at bottom

---

## Home page layout

### 1) Hero section

*Goal:* Immediately communicate authority and breadth.

*Content structure:*

* Eyebrow: Authorized dealer / Pan-India supply
* H1: Building Materials for Projects, Dealers & Contractors
* Supporting text: mention cement, steel, chemicals, AAC blocks, shuttering plywood, pinewood, epoxy and flooring
* Primary CTA: *Get Bulk Quote*
* Secondary CTA: *View Products*
* Quick action chips:

  * Same day response
  * Bulk pricing
  * Pan-India delivery
  * Authentic brands
* Right side visual:

  * collage of products / warehouse / trucks / material textures
  * floating stat cards

### 2) Trust strip

* UltraTech authorized badge
* Partner logo marquee
* Counters:

  * Product categories
  * Trusted partner brands
  * Pan-India supply
  * Fast response

### 3) Product categories section

Grid of large category cards:

* Cement & RMC
* Steel & Steel Fibers
* Construction Chemicals
* AAC Blocks
* Shuttering Plywood & Pinewood
* Epoxy / PU / Industrial Flooring
* Insulation

Each card should include:

* icon or image
* short description
* “Explore category”

### 4) Why choose SGPCC

4-column value proposition:

* Authentic products
* Reliable sourcing
* Bulk order support
* Fast quote turnaround

### 5) Featured brands / trusted partners

* Branded grid with hover reveal
* CTA to full Partners page

### 6) Applications section

Show where materials are used:

* Residential projects
* Commercial buildings
* Warehouses
* Factories
* Infrastructure
* Waterproofing & repair projects

### 7) How it works

3-step process:

1. Share requirement
2. Get technical + commercial quote
3. Receive supply / dispatch support

### 8) Testimonial / trust statement section

Even if there are no formal testimonials yet, use:

* dealer trust messages
* project supply reliability statements
* “Preferred by contractors and distributors” messaging

### 9) CTA banner

Dark section with strong copy:

* Need urgent supply or bulk pricing?
* Call / WhatsApp / Quote form

### 10) Footer

* quick links
* contact info
* email
* office address
* business hours
* maps link
* social / WhatsApp

---

## Products page

### Goals

* Make discovery easy
* Feel much more premium than a catalog list
* Serve both SEO and procurement needs

### Structure

#### A. Intro hero

* H1: Building Products & Construction Materials
* Short copy for B2B intent
* Search bar
* Filter chips

#### B. Filter / sorting system

* Category
* Brand
* Use case
* Availability
* Bulk only / retail inquiry

#### C. Product category sections

Each category card should include:

* cover image
* category description
* sub-items / examples
* quick inquiry CTA

#### D. Recommended product detail content blocks

For each product detail page:

* product name
* breadcrumb
* gallery
* key highlights
* specifications table
* available brands
* applications
* packaging / supply notes
* FAQ
* CTA sidebar with phone/WhatsApp/form
* related products

### Suggested initial categories from current site

* Cement (Grey & RMC)
* Steel & Steel Fibers
* Construction Chemicals
* AAC Blocks
* Shuttering Plywood
* Pinewood
* Epoxy Flooring
* PU Flooring
* Industrial Flooring Systems
* Insulation Materials

---

## Trusted Partners page

### Goals

* Build credibility quickly
* Make partner network feel real and strong

### Layout

1. Hero with heading and trust copy
2. Stats row
3. Featured partner logos grid
4. Partner spotlight cards

   * UltraTech
   * Pidilite
   * MYK Laticrete
   * Sika
   * Birla White
   * Fosroc
   * Mapei
   * Kryton
   * Supreme
   * STP
   * MC-Bauchemie
   * BASF / MBCC style legacy references where appropriate
5. “Why our partnerships matter” section
6. CTA banner for bulk enquiries

### Partner card content

* brand logo
* category served
* what it is used for
* trusted supply note

---

## Industries / Applications page

This page is important because buyers often think in use-cases, not product names.

### Sections

* Hero
* Industry grid:

  * Residential
  * Commercial
  * Industrial
  * Warehouse & logistics
  * Repair & waterproofing
  * Flooring systems
* Recommended materials by use-case
* Consultation CTA

---

## About page

### Sections

* Company introduction
* Mission and promise
* Why customers trust us
* Authorised dealer positioning
* Operational strength
* Team / contact persons
* Office / warehouse presence
* CTA

### Add founder / team credibility box

Use real names and numbers where appropriate.

---

## Delivery & Service Areas page

This page will help SEO and real buyer confidence.

### Sections

* Pan-India delivery promise
* Major regions / states served
* Supply model
* Bulk order process
* Dispatch / logistics explanation
* Quote CTA

---

## Contact / Get Quote page

### Structure

1. Hero with urgency-oriented copy
2. Quick actions row

   * Call Kamal Goyal
   * Call Rinku Goyal
   * Office number
   * WhatsApp
   * Email
3. Quote form

   * Name
   * Company name
   * Phone
   * Email
   * Product category
   * Quantity / requirement
   * Delivery location
   * Message
4. Office card with map embed
5. FAQ snippet below form

### Sticky mobile actions

* Call now
* WhatsApp now
* Get quote

---

## FAQ page

Questions to include:

* Do you supply across India?
* Do you handle bulk orders for projects?
* Which brands do you deal in?
* How fast can I get a quote?
* Can I get product recommendations for my project?
* Do you provide technical construction chemical guidance?
* What details should I share for accurate pricing?

---

## Mobile-first UX rules

* Hero content stacked with CTA above the fold
* Large tap targets
* Sticky bottom bar for Call / WhatsApp / Quote
* 1-column cards on small screens
* Horizontal scroll only for logo rows or chips, never for content
* Product filters should become bottom sheet / drawer on mobile
* Forms should use large fields and quick-pick chips

---

## Suggested component system for Next.js

### Core reusable components

* Header
* MobileNavDrawer
* HeroSection
* SectionHeading
* CTAButtons
* TrustBadge
* StatsStrip
* ProductCategoryCard
* BrandLogoGrid
* PartnerCard
* ApplicationCard
* TestimonialCard
* QuoteForm
* ContactCard
* StickyMobileCTA
* FAQAccordion
* Footer

### Design tokens

* spacing scale: 4 / 8 / 12 / 16 / 24 / 32 / 48 / 64 / 96
* radius scale: md / xl / 2xl
* container widths: 1280 max
* section padding: py-16 mobile, py-24 desktop

---

## Recommended Next.js structure

txt
src/
  app/
    page.tsx
    products/
      page.tsx
      [slug]/page.tsx
    partners/page.tsx
    applications/page.tsx
    about/page.tsx
    delivery/page.tsx
    contact/page.tsx
    faq/page.tsx
  components/
    layout/
    home/
    products/
    partners/
    shared/
  data/
    products.ts
    partners.ts
    faq.ts
    site.ts
  lib/
    utils.ts
  styles/


---

## Content strategy suggestions

### SEO-friendly page focus

* Home: building products supplier in India / construction materials supplier
* Products: product category keywords
* Partners: authorised dealer / trusted brands
* Delivery: bulk supply / pan India delivery
* Contact: get quote / construction materials inquiry

### Copywriting style

* Avoid generic corporate fluff
* Speak directly to contractors, procurement teams, distributors, and project owners
* Use concrete phrases like:

  * bulk pricing
  * urgent delivery
  * authentic products
  * authorised dealer
  * pan-India supply
  * project material support

---

## Homepage section order recommendation

1. Hero
2. Trust strip
3. Product categories
4. Why choose us
5. Featured partner brands
6. Applications / industries
7. Process steps
8. Contact CTA banner
9. Footer

---

## Best upgrades compared to the current site

* Stronger B2B brand identity
* Full product discovery experience instead of simple service blocks
* Dedicated partners page for credibility
* Use-case driven applications page
* Better quote flow and contact capture
* More SEO-ready architecture
* Better mobile interaction with fixed call/WhatsApp/quote actions
* Reusable design system for future growth

---

##

---

## Final creative direction

Think of the redesign as:
*“UltraTech-authorized industrial supplier meets modern premium B2B catalog.”*

It should feel:

* more premium
* more trustworthy
* more structured
* more conversion-focused
* better on mobile than the current version


this is the reference i have given you to develop it?

 https://github.com/Anujsharma2590/spfcc-workspace

if you need to ask anything please ask