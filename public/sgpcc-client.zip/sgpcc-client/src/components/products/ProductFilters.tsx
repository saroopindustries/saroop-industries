"use client";

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Filter } from "lucide-react";
import { categories, getUniqueBrands } from "@/data/products";
import { cn } from "@/lib/utils";

interface ProductFiltersProps {
  search: string;
  onSearchChange: (v: string) => void;
  categorySlug: string | null;
  onCategoryChange: (v: string | null) => void;
  brand: string | null;
  onBrandChange: (v: string | null) => void;
}

export function ProductFilters({
  search,
  onSearchChange,
  categorySlug,
  onCategoryChange,
  brand,
  onBrandChange,
}: ProductFiltersProps) {
  const [sheetOpen, setSheetOpen] = useState(false);
  const brands = getUniqueBrands();

  const clearFilters = () => {
    onCategoryChange(null);
    onBrandChange(null);
    onSearchChange("");
    setSheetOpen(false);
  };

  const hasFilters = categorySlug || brand || search;

  const FilterPanel = () => (
    <div className="space-y-4">
      <div>
        <label className="text-sm font-medium mb-2 block">Category</label>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => onCategoryChange(null)}
            className={cn(
              "rounded-full border px-3 py-1.5 text-sm transition-colors",
              !categorySlug
                ? "border-primary bg-primary/10 text-primary"
                : "border-border hover:bg-muted"
            )}
          >
            All
          </button>
          {categories.map((c) => (
            <button
              key={c.slug}
              type="button"
              onClick={() => onCategoryChange(c.slug)}
              className={cn(
                "rounded-full border px-3 py-1.5 text-sm transition-colors",
                categorySlug === c.slug
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border hover:bg-muted"
              )}
            >
              {c.name}
            </button>
          ))}
        </div>
      </div>
      <div>
        <label className="text-sm font-medium mb-2 block">Brand</label>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => onBrandChange(null)}
            className={cn(
              "rounded-full border px-3 py-1.5 text-sm transition-colors",
              !brand ? "border-primary bg-primary/10 text-primary" : "border-border hover:bg-muted"
            )}
          >
            All
          </button>
          {brands.map((b) => (
            <button
              key={b}
              type="button"
              onClick={() => onBrandChange(b)}
              className={cn(
                "rounded-full border px-3 py-1.5 text-sm transition-colors",
                brand === b ? "border-primary bg-primary/10 text-primary" : "border-border hover:bg-muted"
              )}
            >
              {b}
            </button>
          ))}
        </div>
      </div>
      {hasFilters && (
        <Button variant="ghost" size="sm" onClick={clearFilters}>
          Clear filters
        </Button>
      )}
    </div>
  );

  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div className="relative flex-1 max-w-md">
        <Input
          type="search"
          placeholder="Search products..."
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pr-4"
        />
      </div>
      <div className="flex items-center gap-2">
        <div className="hidden lg:block flex-1 max-w-2xl">
          <FilterPanel />
        </div>
        <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
          <SheetTrigger asChild className="lg:hidden">
            <Button variant="outline" size="icon" aria-label="Open filters">
              <Filter className="size-4" />
              {hasFilters && (
                <Badge className="absolute -top-1 -right-1 size-4 p-0 flex items-center justify-center text-[10px]">
                  1
                </Badge>
              )}
            </Button>
          </SheetTrigger>
          <SheetContent side="bottom" className="h-[80vh] overflow-y-auto">
            <SheetHeader>
              <SheetTitle>Filters</SheetTitle>
            </SheetHeader>
            <div className="mt-6">
              <FilterPanel />
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </div>
  );
}
