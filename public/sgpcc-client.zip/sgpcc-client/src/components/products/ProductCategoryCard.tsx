import Link from "next/link";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { ProductCategory } from "@/data/products";
import { getCategoryProducts } from "@/data/products";
import { cn } from "@/lib/utils";

interface ProductCategoryCardProps {
  category: ProductCategory;
  className?: string;
}

export function ProductCategoryCard({ category, className }: ProductCategoryCardProps) {
  const categoryProducts = getCategoryProducts(category);
  const sampleProducts = categoryProducts.slice(0, 5);

  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader>
        <h2 id={category.slug} className="font-heading text-xl font-semibold scroll-mt-24">
          {category.name}
        </h2>
        {category.description && (
          <p className="text-sm text-muted-foreground">{category.description}</p>
        )}
      </CardHeader>
      <CardContent>
        {sampleProducts.length > 0 ? (
          <ul className="space-y-1 text-sm">
            {sampleProducts.map((p) => (
              <li key={p.id}>
                <Link
                  href={`/products/${p.slug}`}
                  className="text-primary hover:underline"
                >
                  {p.name}
                </Link>
              </li>
            ))}
            {categoryProducts.length > 5 && (
              <li className="text-muted-foreground">
                +{categoryProducts.length - 5} more
              </li>
            )}
          </ul>
        ) : (
          <p className="text-sm text-muted-foreground">
            Enquire for availability and pricing.
          </p>
        )}
      </CardContent>
      <CardFooter>
        <Button variant="outline" size="sm" asChild>
          <Link href="/contact">Quick inquiry</Link>
        </Button>
      </CardFooter>
    </Card>
  );
}
