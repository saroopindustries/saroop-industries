"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export interface StatItem {
  value: string | number;
  label: string;
}

interface StatsStripProps {
  items: StatItem[];
  className?: string;
}

export function StatsStrip({ items, className }: StatsStripProps) {
  return (
    <div
      className={cn(
        "grid grid-cols-2 gap-6 sm:grid-cols-4",
        className
      )}
    >
      {items.map((item, i) => (
        <motion.div
          key={item.label}
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.3, delay: i * 0.05 }}
          className="text-center"
        >
          <p className="font-heading text-2xl font-bold text-primary sm:text-3xl">
            {item.value}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">{item.label}</p>
        </motion.div>
      ))}
    </div>
  );
}
