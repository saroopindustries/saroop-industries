import { cn } from "@/lib/utils";

interface TrustBadgeProps {
  label: string;
  className?: string;
}

export function TrustBadge({ label, className }: TrustBadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border border-success/30 bg-success/10 px-3 py-1 text-xs font-medium text-success",
        className
      )}
    >
      {label}
    </span>
  );
}
