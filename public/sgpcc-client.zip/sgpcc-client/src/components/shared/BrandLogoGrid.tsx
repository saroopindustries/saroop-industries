"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { useState } from "react";
import { config } from "@/data/site";
import { cn } from "@/lib/utils";

interface BrandLogoGridProps {
  className?: string;
  maxItems?: number;
  monochrome?: boolean;
}

function PartnerLogo({ partner, monochrome }: { partner: { name: string; logo: string; url: string }; monochrome: boolean }) {
  const [imgError, setImgError] = useState(false);
  return (
    <Link
      href={partner.url}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        "relative flex h-16 w-full items-center justify-center rounded-lg border border-border bg-card p-3 transition-all hover:border-primary/30 hover:shadow-sm",
        monochrome && "grayscale hover:grayscale-0"
      )}
      aria-label={partner.name}
    >
      {imgError ? (
        <span className="text-center text-xs font-medium text-muted-foreground line-clamp-2">
          {partner.name}
        </span>
      ) : (
        <Image
          src={partner.logo}
          alt=""
          width={120}
          height={48}
          className="object-contain max-h-10 w-auto"
          unoptimized
          onError={() => setImgError(true)}
        />
      )}
    </Link>
  );
}

export function BrandLogoGrid({
  className,
  maxItems,
  monochrome = true,
}: BrandLogoGridProps) {
  const partners = maxItems ? config.partners.slice(0, maxItems) : config.partners;

  return (
    <div
      className={cn(
        "grid grid-cols-3 gap-4 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7",
        className
      )}
    >
      {partners.map((partner, i) => (
        <motion.div
          key={partner.name}
          initial={{ opacity: 0, y: 8 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.3, delay: i * 0.03 }}
          className="flex items-center justify-center"
        >
          <PartnerLogo partner={partner} monochrome={monochrome} />
        </motion.div>
      ))}
    </div>
  );
}
