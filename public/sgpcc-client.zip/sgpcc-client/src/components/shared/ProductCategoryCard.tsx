import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ProductCategoryCardProps {
  title: string;
  description?: string;
  href: string;
  icon?: React.ReactNode;
  className?: string;
}

export function ProductCategoryCard({
  title,
  description,
  href,
  icon,
  className,
}: ProductCategoryCardProps) {
  return (
    <Card
      className={cn(
        "group overflow-hidden transition-shadow hover:shadow-md",
        className
      )}
    >
      <CardHeader className="pb-2">
        {icon && (
          <div className="mb-2 flex size-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
            {icon}
          </div>
        )}
        <h3 className="font-heading text-lg font-semibold">{title}</h3>
      </CardHeader>
      {description && (
        <CardContent className="pb-2">
          <p className="text-sm text-muted-foreground line-clamp-2">
            {description}
          </p>
        </CardContent>
      )}
      <CardFooter className="pt-2">
        <Button variant="ghost" size="sm" className="group-hover:translate-x-1 transition-transform" asChild>
          <Link href={href}>
            Explore category
            <ArrowRight className="size-4 ml-1" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
}
