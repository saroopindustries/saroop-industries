"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { config } from "@/data/site";
import { categories } from "@/data/products";

export function QuoteForm() {
  const router = useRouter();
  const [status, setStatus] = useState<"idle" | "sending" | "done" | "error">("idle");

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus("sending");
    const form = e.currentTarget;
    const data = new FormData(form);
    const body = Object.fromEntries(data.entries());

    // Client-side only: redirect to thank-you. In production, POST to an API or use Formspree.
    try {
      const params = new URLSearchParams(body as Record<string, string>);
      const whatsappUrl = `https://wa.me/${config.contacts.whatsapp.replace(/\D/g, "")}?text=${encodeURIComponent(
        `Quote request:\nName: ${body.name}\nCompany: ${body.company}\nPhone: ${body.phone}\nEmail: ${body.email}\nCategory: ${body.category}\nQuantity: ${body.quantity}\nLocation: ${body.location}\nMessage: ${body.message}`
      )}`;
      window.open(whatsappUrl, "_blank");
      router.push("/thank-you");
      setStatus("done");
    } catch {
      setStatus("error");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="text-sm font-medium mb-1 block">
            Name *
          </label>
          <Input id="name" name="name" required placeholder="Your name" />
        </div>
        <div>
          <label htmlFor="company" className="text-sm font-medium mb-1 block">
            Company name
          </label>
          <Input id="company" name="company" placeholder="Company" />
        </div>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="phone" className="text-sm font-medium mb-1 block">
            Phone *
          </label>
          <Input id="phone" name="phone" type="tel" required placeholder="+91" />
        </div>
        <div>
          <label htmlFor="email" className="text-sm font-medium mb-1 block">
            Email *
          </label>
          <Input id="email" name="email" type="email" required placeholder="email@example.com" />
        </div>
      </div>
      <div>
        <label htmlFor="category" className="text-sm font-medium mb-1 block">
          Product category
        </label>
        <select
          id="category"
          name="category"
          className="flex h-10 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm"
        >
          <option value="">Select category</option>
          {categories.map((c) => (
            <option key={c.id} value={c.name}>
              {c.name}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="quantity" className="text-sm font-medium mb-1 block">
          Quantity / requirement
        </label>
        <Input id="quantity" name="quantity" placeholder="e.g. 100 bags, 5 MT" />
      </div>
      <div>
        <label htmlFor="location" className="text-sm font-medium mb-1 block">
          Delivery location
        </label>
        <Input id="location" name="location" placeholder="City, State" />
      </div>
      <div>
        <label htmlFor="message" className="text-sm font-medium mb-1 block">
          Message
        </label>
        <textarea
          id="message"
          name="message"
          rows={4}
          className="flex w-full rounded-lg border border-input bg-background px-3 py-2 text-sm"
          placeholder="Describe your requirement..."
        />
      </div>
      <Button type="submit" disabled={status === "sending"}>
        {status === "sending" ? "Sending..." : "Submit enquiry"}
      </Button>
      {status === "error" && (
        <p className="text-sm text-destructive">Something went wrong. Please try again or call us.</p>
      )}
    </form>
  );
}
