import Link from "next/link";
import { Button } from "@/components/ui/button";

interface CTAButtonsProps {
  primaryLabel?: string;
  primaryHref?: string;
  secondaryLabel?: string;
  secondaryHref?: string;
  className?: string;
}

export function CTAButtons({
  primaryLabel = "Get Bulk Quote",
  primaryHref = "/contact",
  secondaryLabel = "View Products",
  secondaryHref = "/products",
  className = "",
}: CTAButtonsProps) {
  return (
    <div className={`flex flex-wrap gap-3 ${className}`}>
      <Button size="lg" asChild>
        <Link href={primaryHref}>{primaryLabel}</Link>
      </Button>
      <Button variant="outline" size="lg" asChild>
        <Link href={secondaryHref}>{secondaryLabel}</Link>
      </Button>
    </div>
  );
}
