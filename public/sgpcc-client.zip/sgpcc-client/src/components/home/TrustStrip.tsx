"use client";

import { motion } from "framer-motion";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";
import "swiper/css";
import { TrustBadge } from "@/components/shared/TrustBadge";
import { StatsStrip } from "@/components/shared/StatsStrip";
import { config } from "@/data/site";

const stats = [
  { value: "7+", label: "Product categories" },
  { value: config.partners.length, label: "Trusted partners" },
  { value: "Pan-India", label: "Supply" },
  { value: "1 hr", label: "Response time" },
];

export function TrustStrip() {
  return (
    <section className="border-y border-border bg-card py-12">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-wrap items-center justify-center gap-4 mb-10"
        >
          <TrustBadge label="Authorized UltraTech Dealer" />
        </motion.div>
        <div className="mb-10 overflow-hidden">
          <Swiper
            modules={[Autoplay]}
            spaceBetween={24}
            slidesPerView={2}
            autoplay={{ delay: 2000, disableOnInteraction: false }}
            breakpoints={{
              640: { slidesPerView: 3 },
              768: { slidesPerView: 4 },
              1024: { slidesPerView: 5 },
            }}
            loop
            className="!pb-2"
          >
            {config.partners.map((partner) => (
              <SwiperSlide key={partner.name}>
                <div className="flex h-14 items-center justify-center rounded-lg border border-border bg-background px-4 grayscale hover:grayscale-0 transition-all">
                  <span className="text-xs font-medium text-muted-foreground truncate w-full text-center">
                    {partner.name}
                  </span>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
        <StatsStrip items={stats} />
      </div>
    </section>
  );
}
