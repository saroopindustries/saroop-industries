"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { BrandLogoGrid } from "@/components/shared/BrandLogoGrid";
import { Button } from "@/components/ui/button";

export function FeaturedPartners() {
  return (
    <section className="py-16 sm:py-24 bg-background">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <SectionHeading
            title="Trusted partners"
            subtitle="We work with leading brands to deliver quality building materials."
          />
        </motion.div>
        <motion.div
          className="mt-12"
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
        >
          <BrandLogoGrid monochrome />
        </motion.div>
        <motion.div
          className="mt-10 flex justify-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <Button variant="outline" asChild>
            <Link href="/partners">View all partners</Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
