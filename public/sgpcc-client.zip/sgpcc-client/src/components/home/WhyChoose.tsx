"use client";

import { motion } from "framer-motion";
import { Shield, Truck, Package, Clock } from "lucide-react";
import { SectionHeading } from "@/components/shared/SectionHeading";

const items = [
  {
    icon: Shield,
    title: "Authentic products",
    description: "Authorised dealer and trusted supply chain for genuine brands.",
  },
  {
    icon: Truck,
    title: "Reliable sourcing",
    description: "Network of distributors and partners for consistent availability.",
  },
  {
    icon: Package,
    title: "Bulk order support",
    description: "Project-based pricing and scheduled deliveries for contractors.",
  },
  {
    icon: Clock,
    title: "Fast quote turnaround",
    description: "Response within 1 hour. WhatsApp and call support for urgent needs.",
  },
];

export function WhyChoose() {
  return (
    <section className="py-16 sm:py-24 bg-muted/40">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <SectionHeading
            title="Why choose SGPCC"
            subtitle="One trusted source for cement, steel, chemicals, and building materials."
          />
        </motion.div>
        <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {items.map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="rounded-2xl border border-border bg-card p-6 shadow-sm"
            >
              <div className="flex size-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <item.icon className="size-6" />
              </div>
              <h3 className="mt-4 font-heading font-semibold text-foreground">
                {item.title}
              </h3>
              <p className="mt-2 text-sm text-muted-foreground">
                {item.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
