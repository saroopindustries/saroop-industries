"use client";

import { motion } from "framer-motion";

export function TestimonialTrust() {
  return (
    <section className="py-16 sm:py-24 bg-muted/40">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center"
        >
          <blockquote className="font-heading text-xl font-medium text-foreground sm:text-2xl">
            Preferred by contractors and distributors for reliable supply of
            cement, steel, chemicals and building materials. We deliver
            authentic products with fast response and pan-India reach.
          </blockquote>
          <p className="mt-4 text-sm text-muted-foreground">
            — SGPCC, Bhiwadi
          </p>
        </motion.div>
      </div>
    </section>
  );
}
