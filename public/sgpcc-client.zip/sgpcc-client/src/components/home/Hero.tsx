"use client";

import { motion } from "framer-motion";
import { TrustBadge } from "@/components/shared/TrustBadge";
import { CTAButtons } from "@/components/shared/CTAButtons";
import { config } from "@/data/site";

const chips = [
  "Same day response",
  "Bulk pricing",
  "Pan-India delivery",
  "Authentic brands",
];

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-background py-16 sm:py-24 lg:py-32">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16 lg:items-center">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="mb-4"
            >
              <TrustBadge label="Authorized dealer · Pan-India supply" />
            </motion.div>
            <motion.h1
              className="font-heading text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Building Materials for Projects, Dealers & Contractors
            </motion.h1>
            <motion.p
              className="mt-6 text-lg text-muted-foreground max-w-xl"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              {config.company.tagline}
            </motion.p>
            <motion.div
              className="mt-8"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <CTAButtons />
            </motion.div>
            <motion.div
              className="mt-8 flex flex-wrap gap-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              {chips.map((chip) => (
                <span
                  key={chip}
                  className="rounded-full border border-border bg-card px-4 py-2 text-sm text-muted-foreground"
                >
                  {chip}
                </span>
              ))}
            </motion.div>
          </div>
          <motion.div
            className="relative hidden lg:block"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="aspect-[4/3] rounded-2xl bg-muted border border-border flex items-center justify-center">
              <p className="text-muted-foreground text-sm">Hero image / product collage</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
