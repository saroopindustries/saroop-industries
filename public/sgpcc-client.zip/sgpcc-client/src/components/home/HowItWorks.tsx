"use client";

import { motion } from "framer-motion";
import { MessageSquare, FileCheck, Truck } from "lucide-react";
import { SectionHeading } from "@/components/shared/SectionHeading";

const steps = [
  {
    icon: MessageSquare,
    title: "Share requirement",
    description: "Tell us your product, quantity and delivery location.",
  },
  {
    icon: FileCheck,
    title: "Get technical + commercial quote",
    description: "We respond with pricing and product details.",
  },
  {
    icon: Truck,
    title: "Receive supply / dispatch support",
    description: "We arrange delivery and support until material reaches you.",
  },
];

export function HowItWorks() {
  return (
    <section className="py-16 sm:py-24 bg-background">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <SectionHeading
            title="How it works"
            subtitle="Three simple steps from enquiry to delivery."
          />
        </motion.div>
        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {steps.map((step, i) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="relative text-center"
            >
              {i < steps.length - 1 && (
                <div className="absolute left-1/2 top-8 hidden h-0.5 w-full bg-border md:block" aria-hidden />
              )}
              <div className="relative mx-auto flex size-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
                <step.icon className="size-8" />
              </div>
              <p className="mt-4 font-heading font-semibold text-foreground">
                {step.title}
              </p>
              <p className="mt-2 text-sm text-muted-foreground">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
