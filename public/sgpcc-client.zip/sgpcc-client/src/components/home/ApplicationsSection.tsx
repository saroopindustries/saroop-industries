"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Building2, Warehouse, Factory, Home, HardHat, Layers } from "lucide-react";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { applications } from "@/data/applications";

const iconMap: Record<string, React.ReactNode> = {
  "residential": <Home className="size-6" />,
  "commercial": <Building2 className="size-6" />,
  "industrial": <Factory className="size-6" />,
  "warehouse-logistics": <Warehouse className="size-6" />,
  "repair-waterproofing": <HardHat className="size-6" />,
  "flooring-systems": <Layers className="size-6" />,
};

export function ApplicationsSection() {
  return (
    <section className="py-16 sm:py-24 bg-muted/40">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <SectionHeading
            title="Industries & applications"
            subtitle="Where our materials are used—from residential to industrial."
          />
        </motion.div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {applications.map((app, i) => (
            <motion.div
              key={app.id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
            >
              <Link
                href={`/applications#${app.slug}`}
                className="block rounded-2xl border border-border bg-card p-6 shadow-sm transition-all hover:border-primary/30 hover:shadow-md"
              >
                <div className="flex size-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  {iconMap[app.slug] ?? <Building2 className="size-6" />}
                </div>
                <h3 className="mt-4 font-heading font-semibold text-foreground">
                  {app.name}
                </h3>
                <p className="mt-2 text-sm text-muted-foreground line-clamp-2">
                  {app.description}
                </p>
              </Link>
            </motion.div>
          ))}
        </div>
        <motion.div
          className="mt-10 flex justify-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <Link
            href="/applications"
            className="text-sm font-medium text-primary hover:underline"
          >
            View all applications →
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
