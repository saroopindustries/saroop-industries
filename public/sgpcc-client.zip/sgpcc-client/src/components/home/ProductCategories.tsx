"use client";

import { motion } from "framer-motion";
import {
  Package,
  Zap,
  Droplets,
  Box,
  TreeDeciduous,
  Layers,
  Thermometer,
} from "lucide-react";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { ProductCategoryCard } from "@/components/shared/ProductCategoryCard";
import { config } from "@/data/site";

const categoryIcons: Record<string, React.ReactNode> = {
  "Cement (Grey & RMC)": <Package className="size-6" />,
  "Steel & Steel Fibers": <Zap className="size-6" />,
  "Construction Chemicals": <Droplets className="size-6" />,
  "AAC Blocks": <Box className="size-6" />,
  "Shuttering Plywood & Pinewood": <TreeDeciduous className="size-6" />,
  "Epoxy, PU & Industrial Flooring": <Layers className="size-6" />,
  Insulation: <Thermometer className="size-6" />,
};

const slugMap: Record<string, string> = {
  "Cement (Grey & RMC)": "cement-rmc",
  "Steel & Steel Fibers": "steel-fibers",
  "Construction Chemicals": "construction-chemicals",
  "AAC Blocks": "aac-blocks",
  "Shuttering Plywood & Pinewood": "plywood-pinewood",
  "Epoxy, PU & Industrial Flooring": "epoxy-flooring",
  Insulation: "insulation",
};

export function ProductCategories() {
  return (
    <section className="py-16 sm:py-24 bg-background">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <SectionHeading
            title="Product categories"
            subtitle="Wholesale supply for projects, contractors and distributors across India."
          />
        </motion.div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {config.services.map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
            >
              <ProductCategoryCard
                title={service.title}
                description={service.description}
                href={`/products?category=${slugMap[service.title] ?? service.title.toLowerCase().replace(/\s+/g, "-")}`}
                icon={categoryIcons[service.title]}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
