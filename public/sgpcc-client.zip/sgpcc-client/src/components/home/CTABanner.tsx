"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Phone, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { config } from "@/data/site";

const whatsappUrl = `https://wa.me/${config.contacts.whatsapp.replace(/\D/g, "")}`;

export function CTABanner() {
  return (
    <section className="py-16 sm:py-24 bg-[#111827] text-white">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto text-center"
        >
          <h2 className="font-heading text-3xl font-bold tracking-tight sm:text-4xl">
            {config.cta.heading}
          </h2>
          <p className="mt-4 text-lg text-gray-300">{config.cta.sub}</p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Button size="lg" variant="secondary" className="bg-white text-[#111827] hover:bg-gray-100" asChild>
              <a href={`tel:${config.contacts.phones[0].number.replace(/\s/g, "")}`}>
                <Phone className="size-5" aria-hidden />
                Call now
              </a>
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10" asChild>
              <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
                <MessageCircle className="size-5" aria-hidden />
                WhatsApp
              </a>
            </Button>
            <Button size="lg" variant="accent" asChild>
              <Link href="/contact">Get Quote</Link>
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
