"use client";

import Link from "next/link";
import { Phone, MessageCircle, FileText } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { config } from "@/data/site";
import { cn } from "@/lib/utils";

interface MobileNavDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function MobileNavDrawer({ open, onOpenChange }: MobileNavDrawerProps) {
  const phone = config.contacts.phones[0];
  const whatsappUrl = `https://wa.me/${config.contacts.whatsapp.replace(/\D/g, "")}`;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="flex flex-col w-full max-w-[320px] sm:max-w-[360px]"
      >
        <SheetHeader>
          <SheetTitle className="font-heading text-primary">
            {config.company.shortName}
          </SheetTitle>
        </SheetHeader>
        <nav className="flex flex-col gap-1 pt-6">
          {config.nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => onOpenChange(false)}
              className={cn(
                "px-3 py-3 text-base font-medium rounded-lg hover:bg-muted transition-colors"
              )}
            >
              {item.label}
            </Link>
          ))}
          <Link
            href="/delivery"
            onClick={() => onOpenChange(false)}
            className="px-3 py-3 text-base font-medium rounded-lg hover:bg-muted transition-colors"
          >
            Delivery
          </Link>
          <Link
            href="/faq"
            onClick={() => onOpenChange(false)}
            className="px-3 py-3 text-base font-medium rounded-lg hover:bg-muted transition-colors"
          >
            FAQ
          </Link>
        </nav>
        <div className="mt-auto pt-6 space-y-3 border-t border-border">
          <Button className="w-full" size="lg" asChild>
            <a
              href={`tel:${phone.number.replace(/\s/g, "")}`}
              onClick={() => onOpenChange(false)}
            >
              <Phone className="size-4" aria-hidden />
              Call {phone.label}
            </a>
          </Button>
          <Button variant="outline" className="w-full" size="lg" asChild>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => onOpenChange(false)}
            >
              <MessageCircle className="size-4" aria-hidden />
              WhatsApp
            </a>
          </Button>
          <Button variant="secondary" className="w-full" size="lg" asChild>
            <Link href="/contact" onClick={() => onOpenChange(false)}>
              <FileText className="size-4" aria-hidden />
              Get Quote
            </Link>
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
