"use client";

import Link from "next/link";
import { Phone, MessageCircle, FileText } from "lucide-react";
import { config } from "@/data/site";

const phone = config.contacts.phones[0];
const whatsappUrl = `https://wa.me/${config.contacts.whatsapp.replace(/\D/g, "")}`;

export function StickyMobileCTA() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 flex border-t border-border bg-background/95 backdrop-blur md:hidden">
      <a
        href={`tel:${phone.number.replace(/\s/g, "")}`}
        className="flex flex-1 flex-col items-center gap-1 py-3 text-xs font-medium text-foreground hover:bg-muted transition-colors"
        aria-label={`Call ${phone.label}`}
      >
        <Phone className="size-5" aria-hidden />
        Call
      </a>
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="flex flex-1 flex-col items-center gap-1 py-3 text-xs font-medium text-foreground hover:bg-muted transition-colors"
        aria-label="WhatsApp"
      >
        <MessageCircle className="size-5" aria-hidden />
        WhatsApp
      </a>
      <Link
        href="/contact"
        className="flex flex-1 flex-col items-center gap-1 py-3 text-xs font-medium text-primary hover:bg-muted transition-colors"
        aria-label="Get Quote"
      >
        <FileText className="size-5" aria-hidden />
        Get Quote
      </Link>
    </div>
  );
}
