import Link from "next/link";
import { Mail, Phone, MapPin, MessageCircle } from "lucide-react";
import { config } from "@/data/site";
import { Separator } from "@/components/ui/separator";

const footerLinks = [
  { label: "Home", href: "/" },
  { label: "Products", href: "/products" },
  { label: "Partners", href: "/partners" },
  { label: "Applications", href: "/applications" },
  { label: "About", href: "/about" },
  { label: "Delivery", href: "/delivery" },
  { label: "Contact", href: "/contact" },
  { label: "FAQ", href: "/faq" },
];

export function Footer() {
  const whatsappUrl = `https://wa.me/${config.contacts.whatsapp.replace(/\D/g, "")}`;
  const mapsUrl =
    "https://www.google.com/maps/search/?api=1&query=" +
    encodeURIComponent(config.contacts.address);

  return (
    <footer className="border-t border-border bg-[#111827] text-white">
      <div className="container mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <p className="font-heading text-lg font-bold text-white">
              {config.company.shortName}
            </p>
            <p className="mt-2 text-sm text-gray-300">
              {config.company.tagline}
            </p>
            <p className="mt-2 text-xs text-gray-400">
              Authorized UltraTech Dealer
            </p>
          </div>

          <div>
            <h3 className="font-heading text-sm font-semibold text-white">
              Quick Links
            </h3>
            <ul className="mt-4 space-y-2">
              {footerLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-gray-300 hover:text-white transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
              <li>
                <Link
                  href="/privacy"
                  className="text-sm text-gray-300 hover:text-white transition-colors"
                >
                  Privacy
                </Link>
              </li>
              <li>
                <Link
                  href="/terms"
                  className="text-sm text-gray-300 hover:text-white transition-colors"
                >
                  Terms
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading text-sm font-semibold text-white">
              Contact
            </h3>
            <ul className="mt-4 space-y-3">
              <li>
                <a
                  href={`mailto:${config.contacts.email}`}
                  className="flex items-center gap-2 text-sm text-gray-300 hover:text-white transition-colors"
                >
                  <Mail className="size-4 shrink-0" aria-hidden />
                  {config.contacts.email}
                </a>
              </li>
              <li>
                <a
                  href={`tel:${config.contacts.phones[0].number.replace(/\s/g, "")}`}
                  className="flex items-center gap-2 text-sm text-gray-300 hover:text-white transition-colors"
                >
                  <Phone className="size-4 shrink-0" aria-hidden />
                  {config.contacts.phones[0].number}
                </a>
              </li>
              <li>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-gray-300 hover:text-white transition-colors"
                >
                  <MessageCircle className="size-4 shrink-0" aria-hidden />
                  WhatsApp
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-heading text-sm font-semibold text-white">
              Visit
            </h3>
            <a
              href={mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 flex items-start gap-2 text-sm text-gray-300 hover:text-white transition-colors"
            >
              <MapPin className="size-4 shrink-0 mt-0.5" aria-hidden />
              <span>{config.contacts.address}</span>
            </a>
          </div>
        </div>

        <Separator className="my-8 bg-gray-700" />

        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between text-sm text-gray-400">
          <p>
            © {new Date().getFullYear()} {config.company.name}. All rights
            reserved.
          </p>
          <p className="font-medium text-gray-300">sgpcc.in · Building India&apos;s Future</p>
        </div>
      </div>
    </footer>
  );
}
