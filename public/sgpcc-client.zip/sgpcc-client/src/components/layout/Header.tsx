"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { config } from "@/data/site";
import { MobileNavDrawer } from "./MobileNavDrawer";
import { cn } from "@/lib/utils";

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-40 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <Link
            href="/"
            className="font-heading text-xl font-bold text-primary flex-shrink-0"
          >
            {config.company.shortName}
          </Link>

          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {config.nav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "px-3 py-2 text-sm font-medium text-foreground/90 rounded-lg hover:bg-muted hover:text-foreground transition-colors"
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-2">
            <Button variant="outline" size="sm" asChild>
              <a href={`tel:${config.contacts.phones[0].number.replace(/\s/g, "")}`}>
                <Phone className="size-4" aria-hidden />
                Call Now
              </a>
            </Button>
            <Button size="sm" asChild>
              <Link href="/contact">Get Quote</Link>
            </Button>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="size-6" />
          </Button>
        </div>
      </header>
      <MobileNavDrawer open={mobileOpen} onOpenChange={setMobileOpen} />
    </>
  );
}
