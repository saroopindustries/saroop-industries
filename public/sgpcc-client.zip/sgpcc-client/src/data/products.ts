export interface Product {
  id: string;
  slug: string;
  name: string;
  categorySlug: string;
  brand: string;
  shortDescription?: string;
  applications?: string[];
  specs?: Record<string, string>;
  image?: string;
}

export interface ProductCategory {
  id: string;
  slug: string;
  name: string;
  description: string;
  productIds: string[];
  image?: string;
}

// Blueprint categories + IndiaMART mapping
export const categories: ProductCategory[] = [
  {
    id: "cement-rmc",
    slug: "cement-rmc",
    name: "Cement (Grey & RMC)",
    description:
      "Authorised dealer of non‑trade UltraTech grey cement & RMC across India.",
    productIds: ["ultratech-opc-43", "opc-cement"],
  },
  {
    id: "steel-fibers",
    slug: "steel-fibers",
    name: "Steel & Steel Fibers",
    description: "Steel and steel fiber solutions for concrete reinforcement.",
    productIds: ["bekaert-3d-dramix"],
  },
  {
    id: "construction-chemicals",
    slug: "construction-chemicals",
    name: "Construction Chemicals",
    description:
      "Admixtures, waterproofing, repair mortars, grouts & sealants.",
    productIds: [
      "sikabond-sbr-plus",
      "sika-plastiment-2001",
      "sika-214-kh",
      "sikalatex-sbr",
      "sika-chapdur-in",
      "fosguard-nitoflor",
      "fosroc-conplast-wl",
      "fosroc-nitobond-ep",
      "fosroc-nitobond-sbr",
      "fosroc-conbextra-gp2",
      "dr-fixit-pidicrete-urp",
      "kryton-waterstop-25kg",
      "kryton-waterstop",
      "ultratech-weather-pro",
      "integral-waterproofing-compound",
      "basf-masterpel-777",
      "myk-laticrete-305",
      "myk-laticrete-sp100",
    ],
  },
  {
    id: "aac-blocks",
    slug: "aac-blocks",
    name: "AAC Blocks",
    description: "Autoclaved aerated concrete blocks for construction.",
    productIds: [],
  },
  {
    id: "plywood-pinewood",
    slug: "plywood-pinewood",
    name: "Shuttering Plywood & Pinewood",
    description: "Shuttering plywood and pinewood for formwork and construction.",
    productIds: [],
  },
  {
    id: "epoxy-flooring",
    slug: "epoxy-flooring",
    name: "Epoxy / PU / Industrial Flooring",
    description: "Epoxy, PU and industrial flooring systems.",
    productIds: [],
  },
  {
    id: "insulation",
    slug: "insulation",
    name: "Insulation Materials",
    description: "Insulation materials for thermal and acoustic protection.",
    productIds: [],
  },
];

export const products: Product[] = [
  // Cement
  {
    id: "ultratech-opc-43",
    slug: "ultratech-opc-43-grade-cement",
    name: "Ultratech OPC 43 Grade Cement",
    categorySlug: "cement-rmc",
    brand: "UltraTech Cement",
    shortDescription: "OPC 43 grade cement for general construction.",
  },
  {
    id: "opc-cement",
    slug: "opc-cement",
    name: "Opc Cement",
    categorySlug: "cement-rmc",
    brand: "UltraTech Cement",
    shortDescription: "Ordinary Portland Cement for construction.",
  },
  // Steel
  {
    id: "bekaert-3d-dramix",
    slug: "bekaert-3d-dramix-steel-fiber",
    name: "Bekaert 3D Dramix Steel Fiber",
    categorySlug: "steel-fibers",
    brand: "Bekaert",
    shortDescription: "3D Dramix steel fiber for concrete reinforcement.",
  },
  // Sika
  {
    id: "sikabond-sbr-plus",
    slug: "sikabond-sbr-plus-waterproofing-chemical",
    name: "Sikabond SBR Plus Waterproofing Chemical",
    categorySlug: "construction-chemicals",
    brand: "Sika",
    shortDescription: "SBR-based waterproofing chemical for concrete.",
  },
  {
    id: "sika-plastiment-2001",
    slug: "sika-plastiment-2001-ns-waterproofing-admixture",
    name: "Sika Plastiment 2001 NS Waterproofing Admixture",
    categorySlug: "construction-chemicals",
    brand: "Sika",
    shortDescription: "Waterproofing admixture for concrete.",
  },
  {
    id: "sika-214-kh",
    slug: "sika-214-kh-cement-grout",
    name: "Sika 214 KH Cement Grout",
    categorySlug: "construction-chemicals",
    brand: "Sika",
    shortDescription: "Cement grout for anchoring and repair.",
  },
  {
    id: "sikalatex-sbr",
    slug: "sikalatex-sbr-multipurpose-polymer",
    name: "SikaLatex SBR Multipurpose Polymer",
    categorySlug: "construction-chemicals",
    brand: "Sika",
    shortDescription: "Multipurpose SBR polymer for bonding and waterproofing.",
  },
  {
    id: "sika-chapdur-in",
    slug: "sika-chapdur-in-floor-hardener",
    name: "Sika Chapdur IN Floor Hardener",
    categorySlug: "construction-chemicals",
    brand: "Sika",
    shortDescription: "Floor hardener for industrial floors.",
  },
  // Fosroc
  {
    id: "fosguard-nitoflor",
    slug: "fosguard-nitoflor-hardtop-non-metallic-floor-hardener",
    name: "Fosguard Nitoflor Hardtop Non Metallic Floor Hardener",
    categorySlug: "construction-chemicals",
    brand: "Fosroc",
    shortDescription: "Non-metallic floor hardener for industrial floors.",
  },
  {
    id: "fosroc-conplast-wl",
    slug: "fosroc-conplast-wl-waterproofing-chemical",
    name: "Fosroc Conplast WL Waterproofing Chemical",
    categorySlug: "construction-chemicals",
    brand: "Fosroc",
    shortDescription: "Integral waterproofing admixture for concrete.",
  },
  {
    id: "fosroc-nitobond-ep",
    slug: "fosroc-nitobond-ep-hardener",
    name: "Fosroc Nitobond EP Hardener",
    categorySlug: "construction-chemicals",
    brand: "Fosroc",
    shortDescription: "Epoxy-based bonding agent and hardener.",
  },
  {
    id: "fosroc-nitobond-sbr",
    slug: "fosroc-nitobond-sbr-latex-bonding-agent",
    name: "Fosroc Nitobond SBR Latex Bonding Agent",
    categorySlug: "construction-chemicals",
    brand: "Fosroc",
    shortDescription: "SBR latex bonding agent for concrete and plaster.",
  },
  {
    id: "fosroc-conbextra-gp2",
    slug: "fosroc-conbextra-gp2-grouting-cement",
    name: "Fosroc Conbextra GP2 Grouting Cement",
    categorySlug: "construction-chemicals",
    brand: "Fosroc",
    shortDescription: "Non-shrink grouting cement for machinery and base plates.",
  },
  // Dr Fixit
  {
    id: "dr-fixit-pidicrete-urp",
    slug: "dr-fixit-pidicrete-urp-waterproofing-chemicals",
    name: "Dr Fixit Pidicrete URP Waterproofing Chemicals",
    categorySlug: "construction-chemicals",
    brand: "Pidilite",
    shortDescription: "Universal waterproofing compound for concrete.",
  },
  // Kryton
  {
    id: "kryton-waterstop-25kg",
    slug: "25kg-kryton-krystol-waterstop-grout-smart-concrete",
    name: "25kg Kryton Krystol Waterstop Grout Smart Concrete",
    categorySlug: "construction-chemicals",
    brand: "Kryton",
    shortDescription: "Crystalline waterproofing grout in 25kg pack.",
  },
  {
    id: "kryton-waterstop",
    slug: "kryton-krystol-waterstop-grout-smart-concrete",
    name: "Kryton Krystol Waterstop Grout Smart Concrete",
    categorySlug: "construction-chemicals",
    brand: "Kryton",
    shortDescription: "Crystalline waterproofing grout for concrete.",
  },
  // Ultratech
  {
    id: "ultratech-weather-pro",
    slug: "ultratech-weather-pro-wp200-waterproofing-liquid",
    name: "Ultratech Weather Pro WP+200 Waterproofing Liquid",
    categorySlug: "construction-chemicals",
    brand: "UltraTech Cement",
    shortDescription: "Integral waterproofing liquid for concrete.",
  },
  {
    id: "integral-waterproofing-compound",
    slug: "integral-waterproofing-compound",
    name: "Integral Waterproofing Compound",
    categorySlug: "construction-chemicals",
    brand: "Various",
    shortDescription: "Integral waterproofing compounds for concrete.",
  },
  // Basf
  {
    id: "basf-masterpel-777",
    slug: "basf-masterpel-777-concrete-admixture",
    name: "Basf MasterPel 777 Concrete Admixture",
    categorySlug: "construction-chemicals",
    brand: "BASF",
    shortDescription: "Concrete admixture for improved performance.",
  },
  // MYK Laticrete
  {
    id: "myk-laticrete-305",
    slug: "myk-laticrete-305-tile-adhesive",
    name: "MYK Laticrete 305 Tile Adhesive",
    categorySlug: "construction-chemicals",
    brand: "MYK Laticrete",
    shortDescription: "Tile adhesive for interior and exterior tiling.",
  },
  {
    id: "myk-laticrete-sp100",
    slug: "myk-laticrete-sp100-tile-joint-adhesive",
    name: "MYK Laticrete SP-100 Tile Joint Adhesive",
    categorySlug: "construction-chemicals",
    brand: "MYK Laticrete",
    shortDescription: "Tile joint adhesive and grout.",
  },
];

const productMap = new Map(products.map((p) => [p.id, p]));
const productBySlug = new Map(products.map((p) => [p.slug, p]));
const categoryBySlug = new Map(categories.map((c) => [c.slug, c]));

export function getProductById(id: string): Product | undefined {
  return productMap.get(id);
}

export function getProductBySlug(slug: string): Product | undefined {
  return productBySlug.get(slug);
}

export function getCategoryBySlug(slug: string): ProductCategory | undefined {
  return categoryBySlug.get(slug);
}

export function getProductsByCategorySlug(
  categorySlug: string
): Product[] {
  return products.filter((p) => p.categorySlug === categorySlug);
}

export function getCategoryProducts(category: ProductCategory): Product[] {
  return category.productIds
    .map((id) => productMap.get(id))
    .filter((p): p is Product => !!p);
}

export function getAllProductSlugs(): string[] {
  return products.map((p) => p.slug);
}

export function getUniqueBrands(): string[] {
  const set = new Set(products.map((p) => p.brand));
  return Array.from(set).sort();
}
