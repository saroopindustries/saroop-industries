export interface FAQItem {
  question: string;
  answer: string;
}

export const faqItems: FAQItem[] = [
  {
    question: "Do you supply across India?",
    answer:
      "Yes. We offer pan-India delivery for cement, steel, construction chemicals, AAC blocks, plywood, and industrial flooring. We work with a network of distributors and logistics partners to serve projects across the country.",
  },
  {
    question: "Do you handle bulk orders for projects?",
    answer:
      "Yes. We specialise in bulk supply for contractors, project owners, and dealers. Share your quantity and delivery location for commercial and technical quote. We support project-based pricing and scheduled deliveries.",
  },
  {
    question: "Which brands do you deal in?",
    answer:
      "We are an authorised UltraTech dealer and work with leading brands including Pidilite (Dr Fixit), MYK Laticrete, Sika, Fosroc, Kryton, Birla White, Supreme, Mapei, BASF, Bekaert, MC-Bauchemie, Master Builders Solutions, STP, and Cipy. View our Partners page for the full list.",
  },
  {
    question: "How fast can I get a quote?",
    answer:
      "We aim to respond within 1 hour during business hours. For urgent requirements, call or WhatsApp the numbers on our Contact page. Include product category, approximate quantity, and delivery location for a quick quote.",
  },
  {
    question: "Can I get product recommendations for my project?",
    answer:
      "Yes. Tell us your project type (residential, commercial, industrial, waterproofing, flooring, etc.) and we can suggest suitable products and brands from our range. We can also arrange technical support where needed.",
  },
  {
    question: "Do you provide technical construction chemical guidance?",
    answer:
      "We can connect you with technical support from our partner brands for admixtures, waterproofing, repair mortars, grouts, and flooring systems. Share your requirement and we will guide you to the right product and application method.",
  },
  {
    question: "What details should I share for accurate pricing?",
    answer:
      "For the best quote, share: product name or category, quantity (bags, kg, cubic metres, etc.), delivery location (city/state), and required timeline. For construction chemicals, mention application (e.g. waterproofing, flooring, repair) so we can suggest the right product.",
  },
];
