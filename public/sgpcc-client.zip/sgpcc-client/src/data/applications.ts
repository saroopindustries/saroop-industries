export interface Application {
  id: string;
  slug: string;
  name: string;
  description: string;
  categorySlugs?: string[];
}

export const applications: Application[] = [
  {
    id: "residential",
    slug: "residential",
    name: "Residential projects",
    description:
      "Cement, steel, blocks, tiles, waterproofing and finishing materials for homes and apartments.",
    categorySlugs: ["cement-rmc", "steel-fibers", "construction-chemicals", "aac-blocks"],
  },
  {
    id: "commercial",
    slug: "commercial",
    name: "Commercial buildings",
    description:
      "Building materials and construction chemicals for offices, retail and mixed-use developments.",
    categorySlugs: ["cement-rmc", "construction-chemicals", "epoxy-flooring"],
  },
  {
    id: "industrial",
    slug: "industrial",
    name: "Industrial",
    description:
      "Heavy-duty flooring, chemicals and structural materials for factories and plants.",
    categorySlugs: ["construction-chemicals", "epoxy-flooring", "steel-fibers"],
  },
  {
    id: "warehouse-logistics",
    slug: "warehouse-logistics",
    name: "Warehouse & logistics",
    description:
      "Industrial flooring, insulation and structural materials for warehouses and logistics hubs.",
    categorySlugs: ["epoxy-flooring", "insulation", "cement-rmc"],
  },
  {
    id: "repair-waterproofing",
    slug: "repair-waterproofing",
    name: "Repair & waterproofing",
    description:
      "Waterproofing chemicals, repair mortars and grouts for basements, terraces and structures.",
    categorySlugs: ["construction-chemicals"],
  },
  {
    id: "flooring-systems",
    slug: "flooring-systems",
    name: "Flooring systems",
    description:
      "Epoxy, PU and industrial flooring systems for commercial and industrial use.",
    categorySlugs: ["epoxy-flooring", "construction-chemicals"],
  },
];
