export interface PartnerSpotlight {
  name: string;
  category: string;
  useFor: string;
  note: string;
}

export const partnerSpotlights: PartnerSpotlight[] = [
  {
    name: "UltraTech Cement",
    category: "Cement & RMC",
    useFor: "Grey cement and ready-mix concrete supply across India.",
    note: "Authorised non-trade dealer. Authentic supply for projects and dealers.",
  },
  {
    name: "Pidilite",
    category: "Construction Chemicals",
    useFor: "Dr Fixit waterproofing, adhesives and construction chemicals.",
    note: "Trusted range for waterproofing and repair solutions.",
  },
  {
    name: "MYK Laticrete",
    category: "Tile Adhesives & Grouts",
    useFor: "Tile adhesives, grouts and flooring systems.",
    note: "Premium tile fixing and joint solutions.",
  },
  {
    name: "Sika",
    category: "Construction Chemicals",
    useFor: "Waterproofing, admixtures, grouts, floor hardeners and repair.",
    note: "Global brand for concrete and construction chemistry.",
  },
  {
    name: "Birla White",
    category: "Cement & White Cement",
    useFor: "White cement and wall care products.",
    note: "Quality white cement for architectural and decorative use.",
  },
  {
    name: "Fosroc",
    category: "Construction Chemicals",
    useFor: "Waterproofing, grouts, floor hardeners, bonding agents.",
    note: "Comprehensive construction chemical solutions.",
  },
  {
    name: "Mapei",
    category: "Construction Chemicals",
    useFor: "Adhesives, waterproofing, grouts and flooring systems.",
    note: "Worldwide leader in building adhesives and chemicals.",
  },
  {
    name: "Kryton",
    category: "Waterproofing",
    useFor: "Crystalline waterproofing and repair systems.",
    note: "Integral crystalline technology for durable waterproofing.",
  },
  {
    name: "Supreme",
    category: "Pipes & Infrastructure",
    useFor: "Pipes and infrastructure products.",
    note: "Reliable piping solutions for construction and infrastructure.",
  },
  {
    name: "STP Limited",
    category: "Construction Materials",
    useFor: "Building and construction materials.",
    note: "Trusted supplier in the construction materials segment.",
  },
  {
    name: "MC-Bauchemie",
    category: "Construction Chemicals",
    useFor: "Admixtures, waterproofing, repair and protection systems.",
    note: "German quality construction chemicals for demanding applications.",
  },
  {
    name: "BASF",
    category: "Construction Chemicals",
    useFor: "Concrete admixtures and construction solutions.",
    note: "Master Builders Solutions range for performance and durability.",
  },
];
