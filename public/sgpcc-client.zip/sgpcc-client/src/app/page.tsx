import { Hero } from "@/components/home/Hero";
import { TrustStrip } from "@/components/home/TrustStrip";
import { ProductCategories } from "@/components/home/ProductCategories";
import { WhyChoose } from "@/components/home/WhyChoose";
import { FeaturedPartners } from "@/components/home/FeaturedPartners";
import { ApplicationsSection } from "@/components/home/ApplicationsSection";
import { HowItWorks } from "@/components/home/HowItWorks";
import { TestimonialTrust } from "@/components/home/TestimonialTrust";
import { CTABanner } from "@/components/home/CTABanner";

export default function Home() {
  return (
    <>
      <Hero />
      <TrustStrip />
      <ProductCategories />
      <WhyChoose />
      <FeaturedPartners />
      <ApplicationsSection />
      <HowItWorks />
      <TestimonialTrust />
      <CTABanner />
    </>
  );
}
