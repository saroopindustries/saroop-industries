import type { Metadata } from "next";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { BrandLogoGrid } from "@/components/shared/BrandLogoGrid";
import { config } from "@/data/site";
import { partnerSpotlights } from "@/data/partners";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { StatsStrip } from "@/components/shared/StatsStrip";

export const metadata: Metadata = {
  title: "Trusted Partners | Authorised Dealer Network | SGPCC",
  description:
    "SGPCC partners with UltraTech, Pidilite, Sika, Fosroc, MYK Laticrete and more. Authorised dealer for construction materials in Bhiwadi and pan-India.",
};

const stats = [
  { value: config.partners.length, label: "Partner brands" },
  { value: "Authorised", label: "UltraTech dealer" },
  { value: "Pan-India", label: "Supply network" },
];

export default function PartnersPage() {
  const spotlightNames = new Set(partnerSpotlights.map((p) => p.name));
  const spotlightMap = new Map(partnerSpotlights.map((p) => [p.name, p]));

  return (
    <div className="min-h-screen bg-background">
      <section className="border-b border-border bg-card py-12 sm:py-16">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            title="Trusted partners"
            subtitle="We work with leading brands to deliver authentic building materials and construction chemicals."
          />
          <div className="mt-10">
            <StatsStrip items={stats} />
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="font-heading text-2xl font-bold mb-8">Featured partners</h2>
          <BrandLogoGrid monochrome={false} />
        </div>
      </section>

      <section className="py-12 sm:py-16 bg-muted/40">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="font-heading text-2xl font-bold mb-8">Partner spotlight</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {config.partners
              .filter((p) => spotlightNames.has(p.name))
              .map((partner) => {
                const spotlight = spotlightMap.get(partner.name);
                return (
                  <div
                    key={partner.name}
                    className="rounded-2xl border border-border bg-card p-6 shadow-sm"
                  >
                    <p className="text-xs font-medium text-primary uppercase tracking-wide">
                      {spotlight?.category ?? "Partner"}
                    </p>
                    <h3 className="mt-2 font-heading text-lg font-semibold">
                      {partner.name}
                    </h3>
                    {spotlight?.useFor && (
                      <p className="mt-2 text-sm text-muted-foreground">
                        {spotlight.useFor}
                      </p>
                    )}
                    {spotlight?.note && (
                      <p className="mt-2 text-sm text-foreground">
                        {spotlight.note}
                      </p>
                    )}
                  </div>
                );
              })}
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="container mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-heading text-2xl font-bold mb-4">
            Why our partnerships matter
          </h2>
          <p className="text-muted-foreground">
            Our authorised dealer status and long-standing relationships with
            leading brands ensure you get genuine products, competitive bulk
            pricing, and reliable supply. We combine multiple product lines so
            you can source cement, steel, chemicals, and flooring from one
            trusted partner.
          </p>
          <Button className="mt-8" asChild>
            <Link href="/contact">Bulk enquiry</Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
