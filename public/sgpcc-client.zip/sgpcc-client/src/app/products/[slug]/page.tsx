import { notFound } from "next/navigation";
import Link from "next/link";
import {
  getProductBySlug,
  getCategoryBySlug,
  getProductsByCategorySlug,
  getAllProductSlugs,
} from "@/data/products";
import { config } from "@/data/site";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Phone, MessageCircle } from "lucide-react";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  return getAllProductSlugs().map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: Props) {
  const { slug } = await params;
  const product = getProductBySlug(slug);
  if (!product) return { title: "Product | SGPCC" };
  return {
    title: `${product.name} | SGPCC`,
    description:
      product.shortDescription ??
      `${product.name} by ${product.brand}. Construction materials from SGPCC, Bhiwadi.`,
  };
}

export default async function ProductDetailPage({ params }: Props) {
  const { slug } = await params;
  const product = getProductBySlug(slug);
  if (!product) notFound();

  const category = getCategoryBySlug(product.categorySlug);
  const related = getProductsByCategorySlug(product.categorySlug).filter(
    (p) => p.id !== product.id
  ).slice(0, 4);

  const whatsappUrl = `https://wa.me/${config.contacts.whatsapp.replace(/\D/g, "")}?text=${encodeURIComponent(`Enquiry for: ${product.name}`)}`;

  return (
    <div className="min-h-screen bg-background py-8 sm:py-12">
      <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <nav className="text-sm text-muted-foreground mb-6" aria-label="Breadcrumb">
          <Link href="/" className="hover:text-foreground">Home</Link>
          <span className="mx-2">/</span>
          <Link href="/products" className="hover:text-foreground">Products</Link>
          {category && (
            <>
              <span className="mx-2">/</span>
              <Link
                href={`/products?category=${category.slug}`}
                className="hover:text-foreground"
              >
                {category.name}
              </Link>
            </>
          )}
          <span className="mx-2">/</span>
          <span className="text-foreground">{product.name}</span>
        </nav>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <h1 className="font-heading text-3xl font-bold tracking-tight text-foreground">
              {product.name}
            </h1>
            <p className="text-muted-foreground">
              Brand: <span className="font-medium text-foreground">{product.brand}</span>
            </p>
            {product.shortDescription && (
              <p className="text-lg text-foreground">{product.shortDescription}</p>
            )}

            {product.applications && product.applications.length > 0 && (
              <div>
                <h2 className="font-heading text-lg font-semibold mb-2">Applications</h2>
                <ul className="list-disc list-inside text-muted-foreground">
                  {product.applications.map((a) => (
                    <li key={a}>{a}</li>
                  ))}
                </ul>
              </div>
            )}

            {product.specs && Object.keys(product.specs).length > 0 && (
              <div>
                <h2 className="font-heading text-lg font-semibold mb-2">Specifications</h2>
                <table className="w-full text-sm border border-border rounded-lg overflow-hidden">
                  <tbody>
                    {Object.entries(product.specs).map(([key, value]) => (
                      <tr key={key} className="border-b border-border last:border-0">
                        <td className="p-3 font-medium bg-muted/50">{key}</td>
                        <td className="p-3">{value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {related.length > 0 && (
              <div>
                <h2 className="font-heading text-lg font-semibold mb-4">Related products</h2>
                <ul className="grid gap-3 sm:grid-cols-2">
                  {related.map((p) => (
                    <li key={p.id}>
                      <Link
                        href={`/products/${p.slug}`}
                        className="block rounded-lg border border-border p-3 hover:border-primary/30 transition-colors text-sm font-medium text-foreground"
                      >
                        {p.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div>
            <Card className="sticky top-24">
              <CardHeader>
                <h2 className="font-heading text-lg font-semibold">Get a quote</h2>
                <p className="text-sm text-muted-foreground">
                  Call or WhatsApp for pricing and availability.
                </p>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full" asChild>
                  <a href={`tel:${config.contacts.phones[0].number.replace(/\s/g, "")}`}>
                    <Phone className="size-4" aria-hidden />
                    Call now
                  </a>
                </Button>
                <Button variant="outline" className="w-full" asChild>
                  <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
                    <MessageCircle className="size-4" aria-hidden />
                    WhatsApp
                  </a>
                </Button>
                <Button variant="secondary" className="w-full" asChild>
                  <Link href="/contact">Request quote form</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
