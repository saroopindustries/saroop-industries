import { Suspense } from "react";
import { ProductsPageClient } from "./ProductsPageClient";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Products | Building Products & Construction Materials | SGPCC",
  description:
    "Building products and construction materials: cement, steel, chemicals, AAC blocks, plywood, epoxy flooring. Bulk supply in Bhiwadi and pan-India.",
};

export default function ProductsPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-background py-12 container mx-auto px-4">Loading...</div>}>
      <ProductsPageClient />
    </Suspense>
  );
}
