"use client";

import { useCallback, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { ProductFilters } from "@/components/products/ProductFilters";
import { ProductCategoryCard } from "@/components/products/ProductCategoryCard";
import {
  categories,
  products,
  getCategoryBySlug,
} from "@/data/products";

function filterProducts(
  search: string,
  categorySlug: string | null,
  brand: string | null
) {
  let list = products;
  const q = search.trim().toLowerCase();
  if (q) {
    list = list.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.shortDescription?.toLowerCase().includes(q)
    );
  }
  if (categorySlug) {
    list = list.filter((p) => p.categorySlug === categorySlug);
  }
  if (brand) {
    list = list.filter((p) => p.brand === brand);
  }
  return list;
}

export function ProductsPageClient() {
  const searchParams = useSearchParams();
  const categoryFromUrl = searchParams.get("category");

  const [search, setSearch] = useState("");
  const [categorySlug, setCategorySlug] = useState<string | null>(
    categoryFromUrl && getCategoryBySlug(categoryFromUrl) ? categoryFromUrl : null
  );
  const [brand, setBrand] = useState<string | null>(null);

  const filteredProducts = useMemo(
    () => filterProducts(search, categorySlug, brand),
    [search, categorySlug, brand]
  );

  const categoriesToShow = useMemo(() => {
    if (categorySlug) {
      const cat = getCategoryBySlug(categorySlug);
      return cat ? [cat] : categories;
    }
    return categories;
  }, [categorySlug]);

  return (
    <div className="min-h-screen bg-background">
      <section className="border-b border-border bg-card py-12 sm:py-16">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            title="Building products & construction materials"
            subtitle="Wholesale supply for projects, contractors and distributors. Search or filter by category and brand."
          />
          <div className="mt-8">
            <ProductFilters
              search={search}
              onSearchChange={setSearch}
              categorySlug={categorySlug}
              onCategoryChange={setCategorySlug}
              brand={brand}
              onBrandChange={setBrand}
            />
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          {search || brand ? (
            <div className="space-y-6">
              <p className="text-sm text-muted-foreground">
                {filteredProducts.length} product(s) found.
              </p>
              {filteredProducts.length > 0 ? (
                <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {filteredProducts.map((p) => (
                    <li key={p.id}>
                      <a
                        href={`/products/${p.slug}`}
                        className="block rounded-xl border border-border bg-card p-4 hover:border-primary/30 transition-colors"
                      >
                        <p className="font-medium text-foreground">{p.name}</p>
                        <p className="text-sm text-muted-foreground mt-1">
                          {p.brand}
                        </p>
                      </a>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-muted-foreground">
                  No products match your filters. Try adjusting search or
                  filters.
                </p>
              )}
            </div>
          ) : (
            <div className="space-y-10">
              {categoriesToShow.map((category) => (
                <ProductCategoryCard key={category.id} category={category} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
