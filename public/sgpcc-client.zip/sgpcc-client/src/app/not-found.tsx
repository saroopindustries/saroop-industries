import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center px-4">
      <h1 className="font-heading text-4xl font-bold text-foreground">404</h1>
      <p className="mt-2 text-muted-foreground text-center">
        The page you are looking for does not exist.
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-4">
        <Button asChild>
          <Link href="/">Home</Link>
        </Button>
        <Button variant="outline" asChild>
          <Link href="/products">Products</Link>
        </Button>
        <Button variant="outline" asChild>
          <Link href="/contact">Contact</Link>
        </Button>
      </div>
    </div>
  );
}
