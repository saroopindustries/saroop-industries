import type { Metadata } from "next";
import Link from "next/link";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { applications } from "@/data/applications";
import { getCategoryBySlug } from "@/data/products";
import { Button } from "@/components/ui/button";
import { Building2, Warehouse, Factory, Home, HardHat, Layers } from "lucide-react";

export const metadata: Metadata = {
  title: "Industries & Applications | Construction Materials by Use Case | SGPCC",
  description:
    "Building materials for residential, commercial, industrial, warehouse, waterproofing and flooring applications. Pan-India supply from SGPCC.",
};

const iconMap: Record<string, React.ReactNode> = {
  residential: <Home className="size-8" />,
  commercial: <Building2 className="size-8" />,
  industrial: <Factory className="size-8" />,
  "warehouse-logistics": <Warehouse className="size-8" />,
  "repair-waterproofing": <HardHat className="size-8" />,
  "flooring-systems": <Layers className="size-8" />,
};

export default function ApplicationsPage() {
  return (
    <div className="min-h-screen bg-background">
      <section className="border-b border-border bg-card py-12 sm:py-16">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            title="Industries & applications"
            subtitle="Find the right materials for your project type. We supply across residential, commercial, industrial and specialist applications."
          />
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {applications.map((app) => (
              <div
                key={app.id}
                id={app.slug}
                className="scroll-mt-24 rounded-2xl border border-border bg-card p-8 shadow-sm"
              >
                <div className="flex size-14 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  {iconMap[app.slug] ?? <Building2 className="size-8" />}
                </div>
                <h2 className="mt-4 font-heading text-xl font-semibold">
                  {app.name}
                </h2>
                <p className="mt-2 text-muted-foreground">{app.description}</p>
                {app.categorySlugs && app.categorySlugs.length > 0 && (
                  <div className="mt-4">
                    <p className="text-sm font-medium text-foreground">
                      Recommended categories
                    </p>
                    <ul className="mt-2 flex flex-wrap gap-2">
                      {app.categorySlugs.map((slug) => {
                        const cat = getCategoryBySlug(slug);
                        return cat ? (
                          <li key={slug}>
                            <Link
                              href={`/products?category=${slug}`}
                              className="text-sm text-primary hover:underline"
                            >
                              {cat.name}
                            </Link>
                          </li>
                        ) : null;
                      })}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="mt-12 text-center">
            <Button asChild>
              <Link href="/contact">Consultation / Quote</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
