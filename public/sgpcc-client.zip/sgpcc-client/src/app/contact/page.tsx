import type { Metadata } from "next";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { QuoteForm } from "@/components/shared/QuoteForm";
import { config } from "@/data/site";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Phone, MessageCircle, Mail, MapPin } from "lucide-react";
import { FAQAccordion } from "@/components/shared/FAQAccordion";
import { faqItems } from "@/data/faq";

export const metadata: Metadata = {
  title: "Contact & Get Quote | SGPCC — Bhiwadi",
  description:
    "Get a quote for cement, steel, construction chemicals and building materials. Call, WhatsApp or fill the form. SGPCC, Bhiwadi.",
};

const whatsappUrl = `https://wa.me/${config.contacts.whatsapp.replace(/\D/g, "")}`;
const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(config.contacts.address)}`;

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-background">
      <section className="border-b border-border bg-card py-12 sm:py-16">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            title="Contact & get a quote"
            subtitle="Call, WhatsApp or send an enquiry. We respond within 1 hour."
          />
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <h2 className="font-heading text-xl font-semibold mb-6">
                Quick actions
              </h2>
              <div className="grid gap-4 sm:grid-cols-2 mb-10">
                {config.contacts.phones.map((phone) => (
                  <a
                    key={phone.label}
                    href={`tel:${phone.number.replace(/\s/g, "")}`}
                    className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 hover:border-primary/30 transition-colors"
                  >
                    <Phone className="size-5 text-primary" aria-hidden />
                    <div>
                      <p className="font-medium text-foreground">{phone.label}</p>
                      <p className="text-sm text-muted-foreground">{phone.number}</p>
                    </div>
                  </a>
                ))}
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 hover:border-primary/30 transition-colors"
                >
                  <MessageCircle className="size-5 text-primary" aria-hidden />
                  <div>
                    <p className="font-medium text-foreground">WhatsApp</p>
                    <p className="text-sm text-muted-foreground">Chat with us</p>
                  </div>
                </a>
                <a
                  href={`mailto:${config.contacts.email}`}
                  className="flex items-center gap-3 rounded-xl border border-border bg-card p-4 hover:border-primary/30 transition-colors"
                >
                  <Mail className="size-5 text-primary" aria-hidden />
                  <div>
                    <p className="font-medium text-foreground">Email</p>
                    <p className="text-sm text-muted-foreground">{config.contacts.email}</p>
                  </div>
                </a>
              </div>

              <h2 className="font-heading text-xl font-semibold mb-6">
                Quote form
              </h2>
              <Card>
                <CardContent className="pt-6">
                  <QuoteForm />
                </CardContent>
              </Card>
            </div>

            <div>
              <Card>
                <CardHeader>
                  <h2 className="font-heading text-lg font-semibold">Office</h2>
                </CardHeader>
                <CardContent className="space-y-4">
                  <a
                    href={mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-2 text-sm text-muted-foreground hover:text-foreground"
                  >
                    <MapPin className="size-4 shrink-0 mt-0.5" aria-hidden />
                    {config.contacts.address}
                  </a>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 sm:py-16 bg-muted/40">
        <div className="container mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <h2 className="font-heading text-xl font-semibold mb-6">
            Frequently asked questions
          </h2>
          <FAQAccordion items={faqItems.slice(0, 3)} />
        </div>
      </section>
    </div>
  );
}
