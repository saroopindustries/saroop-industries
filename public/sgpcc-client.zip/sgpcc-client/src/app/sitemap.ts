import { config } from "@/data/site";
import { getAllProductSlugs } from "@/data/products";

export default function sitemap() {
  const base = config.siteUrl;

  const staticRoutes = [
    "",
    "/products",
    "/partners",
    "/applications",
    "/about",
    "/delivery",
    "/contact",
    "/faq",
    "/thank-you",
    "/privacy",
    "/terms",
  ].map((path) => ({
    url: `${base}${path}`,
    lastModified: new Date(),
    changeFrequency: path === "" ? "weekly" as const : "monthly" as const,
    priority: path === "" ? 1 : 0.8,
  }));

  const productRoutes = getAllProductSlugs().map((slug) => ({
    url: `${base}/products/${slug}`,
    lastModified: new Date(),
    changeFrequency: "monthly" as const,
    priority: 0.6,
  }));

  return [...staticRoutes, ...productRoutes];
}
