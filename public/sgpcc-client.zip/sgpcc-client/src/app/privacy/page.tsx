import type { Metadata } from "next";
import { SectionHeading } from "@/components/shared/SectionHeading";

export const metadata: Metadata = {
  title: "Privacy Policy | SGPCC",
  description: "Privacy policy for SGPCC website.",
};

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background py-12 sm:py-16">
      <div className="container mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <SectionHeading title="Privacy policy" />
        <div className="mt-8 prose prose-neutral dark:prose-invert max-w-none text-muted-foreground">
          <p>
            This page is a placeholder. Please add your privacy policy content
            here or link to an external document. Typically it covers how you
            collect, use and protect visitor information (e.g. contact form
            data, cookies).
          </p>
        </div>
      </div>
    </div>
  );
}
