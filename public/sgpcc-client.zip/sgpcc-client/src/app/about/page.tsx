import type { Metadata } from "next";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { config } from "@/data/site";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Phone, MapPin } from "lucide-react";

export const metadata: Metadata = {
  title: "About Us | SGPCC — Shree Ganesh Plywood & Construction Chemicals",
  description:
    "SGPCC is a trusted supplier of cement, steel, chemicals, AAC blocks, plywood and industrial flooring. Authorised UltraTech dealer, Bhiwadi.",
};

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <section className="border-b border-border bg-card py-12 sm:py-16">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            title="About SGPCC"
            subtitle="One trusted source for building materials and construction chemicals."
          />
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="container mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 space-y-8">
          <p className="text-lg text-foreground">{config.company.about}</p>
          <p className="text-muted-foreground">{config.company.tagline}</p>

          <div className="rounded-2xl border border-border bg-muted/40 p-6">
            <h2 className="font-heading text-xl font-semibold mb-4">
              Why customers trust us
            </h2>
            <ul className="space-y-2 text-muted-foreground">
              <li>• Authorised UltraTech dealer for cement and RMC</li>
              <li>• Direct partnerships with leading construction chemical brands</li>
              <li>• Pan-India delivery and bulk order support</li>
              <li>• Fast quote turnaround and responsive support</li>
            </ul>
          </div>

          <div>
            <h2 className="font-heading text-xl font-semibold mb-4">
              Contact persons
            </h2>
            <ul className="space-y-3">
              {config.contacts.phones.map((phone) => (
                <li key={phone.label}>
                  <a
                    href={`tel:${phone.number.replace(/\s/g, "")}`}
                    className="flex items-center gap-2 text-foreground hover:text-primary"
                  >
                    <Phone className="size-4" aria-hidden />
                    {phone.label}: {phone.number}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h2 className="font-heading text-xl font-semibold mb-4">Office</h2>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(config.contacts.address)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-start gap-2 text-muted-foreground hover:text-foreground"
            >
              <MapPin className="size-4 shrink-0 mt-0.5" aria-hidden />
              {config.contacts.address}
            </a>
          </div>

          <Button asChild>
            <Link href="/contact">Get in touch</Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
