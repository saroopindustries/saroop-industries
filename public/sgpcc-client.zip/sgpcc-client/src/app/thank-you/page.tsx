import type { Metadata } from "next";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export const metadata: Metadata = {
  title: "Thank you | SGPCC",
  description: "We have received your enquiry and will get back soon.",
};

export default function ThankYouPage() {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center px-4">
      <h1 className="font-heading text-2xl font-bold text-foreground">
        Thank you
      </h1>
      <p className="mt-2 text-muted-foreground text-center max-w-md">
        We have received your enquiry and will get back to you within 1 hour.
        For urgent needs, please call or WhatsApp us.
      </p>
      <div className="mt-8 flex gap-4">
        <Button asChild>
          <Link href="/">Back to home</Link>
        </Button>
        <Button variant="outline" asChild>
          <Link href="/products">View products</Link>
        </Button>
      </div>
    </div>
  );
}
