import type { Metadata } from "next";
import { Manrope, Inter } from "next/font/google";
import "./globals.css";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { StickyMobileCTA } from "@/components/layout/StickyMobileCTA";

const manrope = Manrope({
  variable: "--font-manrope",
  subsets: ["latin"],
  display: "swap",
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "SGPCC — Shree Ganesh Plywood & Construction Chemicals",
  description:
    "Authorised UltraTech dealer. Supplier of cement, steel, AAC blocks, shuttering plywood, pinewood, epoxy & industrial flooring in Bhiwadi/Alwar, Rajasthan.",
  metadataBase: new URL("https://sgpcc.in"),
  openGraph: {
    title: "SGPCC — Shree Ganesh Plywood & Construction Chemicals",
    description:
      "Authorised UltraTech dealer. One stop solution for cement, steel, chemicals, AAC blocks, plywood, epoxy & industrial flooring.",
    url: "https://sgpcc.in",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${manrope.variable} ${inter.variable} font-sans antialiased pb-16 md:pb-0`}
      >
        <Header />
        <main>{children}</main>
        <Footer />
        <StickyMobileCTA />
      </body>
    </html>
  );
}
