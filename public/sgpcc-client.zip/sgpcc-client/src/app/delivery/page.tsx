import type { Metadata } from "next";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Delivery & Service Areas | Pan-India Bulk Supply | SGPCC",
  description:
    "Pan-India delivery for cement, steel, construction chemicals and building materials. Bulk order process and dispatch support from SGPCC, Bhiwadi.",
};

export default function DeliveryPage() {
  return (
    <div className="min-h-screen bg-background">
      <section className="border-b border-border bg-card py-12 sm:py-16">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            title="Delivery & service areas"
            subtitle="We deliver across India with reliable logistics and bulk order support."
          />
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="container mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 space-y-10">
          <div>
            <h2 className="font-heading text-xl font-semibold mb-2">
              Pan-India delivery
            </h2>
            <p className="text-muted-foreground">
              We supply cement, steel, construction chemicals, AAC blocks,
              plywood, and industrial flooring across India. Our network of
              distributors and logistics partners enables us to serve projects
              in major states and regions.
            </p>
          </div>

          <div>
            <h2 className="font-heading text-xl font-semibold mb-2">
              Supply model
            </h2>
            <p className="text-muted-foreground">
              We work with contractors, project owners, dealers and distributors.
              Share your quantity, product and delivery location for a
              commercial quote. We support both full truck loads and smaller
              consignments where feasible.
            </p>
          </div>

          <div>
            <h2 className="font-heading text-xl font-semibold mb-2">
              Bulk order process
            </h2>
            <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
              <li>Share product, quantity and delivery location</li>
              <li>Receive quote and confirm order</li>
              <li>We arrange dispatch and share tracking details</li>
              <li>Delivery and support until material reaches you</li>
            </ol>
          </div>

          <Button asChild>
            <Link href="/contact">Request a quote</Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
