import type { Metadata } from "next";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { FAQAccordion } from "@/components/shared/FAQAccordion";
import { faqItems } from "@/data/faq";

export const metadata: Metadata = {
  title: "FAQ | SGPCC — Construction Materials",
  description:
    "Frequently asked questions about SGPCC: pan-India delivery, bulk orders, brands, quotes and construction materials.",
};

export default function FAQPage() {
  return (
    <div className="min-h-screen bg-background">
      <section className="border-b border-border bg-card py-12 sm:py-16">
        <div className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            title="Frequently asked questions"
            subtitle="Quick answers about delivery, orders, brands and quotes."
          />
        </div>
      </section>

      <section className="py-12 sm:py-16">
        <div className="container mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <FAQAccordion items={faqItems} />
        </div>
      </section>
    </div>
  );
}
