import type { Metadata } from "next";
import { SectionHeading } from "@/components/shared/SectionHeading";

export const metadata: Metadata = {
  title: "Terms & Conditions | SGPCC",
  description: "Terms and conditions for SGPCC website.",
};

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-background py-12 sm:py-16">
      <div className="container mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
        <SectionHeading title="Terms & conditions" />
        <div className="mt-8 prose prose-neutral dark:prose-invert max-w-none text-muted-foreground">
          <p>
            This page is a placeholder. Please add your terms and conditions
            here or link to an external document.
          </p>
        </div>
      </div>
    </div>
  );
}
